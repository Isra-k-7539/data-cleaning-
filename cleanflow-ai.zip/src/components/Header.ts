import { AppState } from '../appState';

export class HeaderComponent {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const header = document.createElement('header');
    header.className = 'header-bar';

    const activeDataset = this.appState.getActiveDataset();
    const qualityScore = activeDataset?.cleanedQuality.overall ?? 100;
    const qualityColor = qualityScore >= 80 ? '#10B981' : qualityScore >= 60 ? '#F59E0B' : '#EF4444';

    header.innerHTML = `
      <div class="header-left">
        <div class="brand-logo">
          <div class="brand-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
            </svg>
          </div>
          <div class="brand-text">
            <span class="brand-title">CleanFlow<span class="brand-ai">AI</span></span>
            <span class="brand-tag">Data Prep & Reporting</span>
          </div>
        </div>

        <!-- Active Dataset Dropdown Selector -->
        <div class="dataset-selector-wrapper">
          <label class="dataset-selector-label">ACTIVE DATASET</label>
          <select id="dataset-select" class="dataset-select">
            ${this.appState.datasets.map(d => `
              <option value="${d.id}" ${d.id === this.appState.activeDatasetId ? 'selected' : ''}>
                ${d.name} (${d.cleanedRows.length} rows)
              </option>
            `).join('')}
          </select>
        </div>
      </div>

      <div class="header-right">
        <!-- Live Quality Score Pill -->
        <div class="quality-badge" title="Data Quality Score calculated based on completeness, uniqueness, and consistency.">
          <span class="quality-dot" style="background-color: ${qualityColor}; box-shadow: 0 0 10px ${qualityColor};"></span>
          <span class="quality-text">Quality Score: <strong style="color: ${qualityColor};">${qualityScore}%</strong></span>
        </div>

        <!-- Global Search Bar -->
        <div class="search-input-box">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
          </svg>
          <input type="text" id="global-search" placeholder="Search dataset rows..." value="${this.appState.searchFilter}">
        </div>

        <!-- 3D Spatial Studio Button -->
        <button id="btn-toggle-3d" class="btn-secondary btn-icon" title="View dataset in 3D Point Constellation">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
            <line x1="12" y1="22.08" x2="12" y2="12"/>
          </svg>
          <span>${this.appState.currentView === '3d_view' ? 'Exit 3D' : '3D Spatial'}</span>
        </button>

        <!-- AI Assistant Trigger Button -->
        <button id="btn-open-ai" class="btn-ai" title="Open AI Data Quality Assistant">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>
          </svg>
          <span>Ask AI</span>
        </button>
      </div>
    `;

    // Event listeners
    const select = header.querySelector<HTMLSelectElement>('#dataset-select');
    select?.addEventListener('change', (e) => {
      this.appState.setActiveDataset((e.target as HTMLSelectElement).value);
    });

    const search = header.querySelector<HTMLInputElement>('#global-search');
    search?.addEventListener('input', (e) => {
      this.appState.setSearchFilter((e.target as HTMLInputElement).value);
    });

    const aiBtn = header.querySelector('#btn-open-ai');
    aiBtn?.addEventListener('click', () => {
      this.appState.toggleAI(true);
    });

    const toggle3DBtn = header.querySelector('#btn-toggle-3d');
    toggle3DBtn?.addEventListener('click', () => {
      if (this.appState.currentView === '3d_view') {
        this.appState.setView('overview');
      } else {
        this.appState.setView('3d_view');
      }
    });

    return header;
  }
}
