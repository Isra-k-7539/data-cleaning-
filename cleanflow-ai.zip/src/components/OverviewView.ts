import { AppState } from '../appState';

export class OverviewView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    const allDatasets = this.appState.datasets;

    const totalRecords = allDatasets.reduce((sum, d) => sum + d.cleanedRows.length, 0);
    const avgScore = Math.round(allDatasets.reduce((sum, d) => sum + d.cleanedQuality.overall, 0) / Math.max(1, allDatasets.length));
    const totalDuplicatesRemoved = allDatasets.reduce((sum, d) => sum + (d.rawRows.length - d.cleanedRows.length), 0);
    const totalMissingHandled = allDatasets.reduce((sum, d) => {
      const rawM = d.rawProfile.reduce((s, p) => s + p.missingCount, 0);
      const cleanM = d.cleanedProfile.reduce((s, p) => s + p.missingCount, 0);
      return sum + Math.max(0, rawM - cleanM);
    }, 0);

    const rawScore = activeDataset?.rawQuality.overall ?? 100;
    const cleanScore = activeDataset?.cleanedQuality.overall ?? 100;

    container.innerHTML = `
      <!-- Welcome Hero Banner -->
      <div class="hero-card">
        <div class="hero-content">
          <div class="hero-badge">ENTERPRISE DATA PREPARATION PLATFORM</div>
          <h1 class="hero-title">From Raw Messy Data to Reliable Insights — Automatically</h1>
          <p class="hero-desc">
            CleanFlow AI automatically profiles dataset health, detects duplicates, imputes missing attributes with median/mode, standardizes dates and locations, and generates interactive executive reporting dashboards.
          </p>
          <div class="hero-actions">
            <button id="hero-btn-workspace" class="btn-primary">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
              Upload or Select Dataset
            </button>
            <button id="hero-btn-auto-clean" class="btn-secondary">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
              </svg>
              Run 1-Click Auto Clean
            </button>
            <button id="hero-btn-report" class="btn-outline">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
              </svg>
              View Executive Dashboard
            </button>
          </div>
        </div>
      </div>

      <!-- KPI Metrics Grid -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-label">TOTAL DATASETS</span>
            <span class="kpi-icon-wrap" style="color: #818cf8; background: rgba(99, 102, 241, 0.15);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 22h14a2 2 0 0 0 2-2V7.5L14.5 2H6a2 2 0 0 0-2 2v4"/><polyline points="14 2 14 8 20 8"/></svg>
            </span>
          </div>
          <div class="kpi-value">${allDatasets.length}</div>
          <div class="kpi-subtext">Active in workspace</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-label">RECORDS PROCESSED</span>
            <span class="kpi-icon-wrap" style="color: #38bdf8; background: rgba(56, 189, 248, 0.15);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            </span>
          </div>
          <div class="kpi-value">${totalRecords}</div>
          <div class="kpi-subtext">Clean rows validated</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-label">AVG QUALITY SCORE</span>
            <span class="kpi-icon-wrap" style="color: #34d399; background: rgba(52, 211, 153, 0.15);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
            </span>
          </div>
          <div class="kpi-value" style="color: ${avgScore >= 80 ? '#34d399' : '#fbbf24'};">${avgScore}%</div>
          <div class="kpi-subtext">Index across all datasets</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-label">DUPLICATES REMOVED</span>
            <span class="kpi-icon-wrap" style="color: #fb7185; background: rgba(251, 113, 133, 0.15);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
            </span>
          </div>
          <div class="kpi-value">${totalDuplicatesRemoved}</div>
          <div class="kpi-subtext">Redundant rows eliminated</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-label">MISSING VALUES HANDLED</span>
            <span class="kpi-icon-wrap" style="color: #fbbf24; background: rgba(251, 191, 36, 0.15);">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </span>
          </div>
          <div class="kpi-value">${totalMissingHandled}</div>
          <div class="kpi-subtext">Imputed via Median/Mode</div>
        </div>
      </div>

      <!-- Active Dataset Focus & Quality Progress Section -->
      <div class="dashboard-row-2col">
        <!-- Quality Improvement Gauge & Scorecard -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Data Quality Index: ${activeDataset?.name ?? 'No Dataset'}</h2>
              <p class="panel-subtitle">Weighted scoring formula evaluating Completeness, Uniqueness, and Consistency</p>
            </div>
            <span class="badge ${cleanScore >= 80 ? 'badge-success' : 'badge-warning'}">
              ${cleanScore >= rawScore ? `+${cleanScore - rawScore}% Improvement` : 'Baseline'}
            </span>
          </div>

          <div class="quality-score-display">
            <div class="quality-circle-wrap">
              <svg viewBox="0 0 100 100" class="gauge-svg">
                <circle cx="50" cy="50" r="42" class="gauge-bg" />
                <circle cx="50" cy="50" r="42" class="gauge-fill"
                  style="stroke-dasharray: 264; stroke-dashoffset: ${264 - (264 * cleanScore) / 100}; stroke: ${cleanScore >= 80 ? '#10B981' : cleanScore >= 60 ? '#F59E0B' : '#EF4444'};" />
              </svg>
              <div class="gauge-center-text">
                <span class="gauge-num">${cleanScore}%</span>
                <span class="gauge-label">Score</span>
              </div>
            </div>

            <div class="quality-stats-breakdown">
              <div class="quality-breakdown-row">
                <span class="qb-label">Raw Baseline Score</span>
                <span class="qb-val">${rawScore}%</span>
              </div>
              <div class="quality-breakdown-row">
                <span class="qb-label">Cleaned Score</span>
                <span class="qb-val" style="color: #34d399; font-weight: 700;">${cleanScore}%</span>
              </div>
              <div class="quality-breakdown-row">
                <span class="qb-label">Completeness</span>
                <span class="qb-val">${activeDataset?.cleanedQuality.dimensions.completeness}%</span>
              </div>
              <div class="quality-breakdown-row">
                <span class="qb-label">Uniqueness</span>
                <span class="qb-val">${activeDataset?.cleanedQuality.dimensions.uniqueness}%</span>
              </div>
              <div class="quality-breakdown-row">
                <span class="qb-label">Consistency</span>
                <span class="qb-val">${activeDataset?.cleanedQuality.dimensions.consistency}%</span>
              </div>
            </div>
          </div>

          <div style="margin-top: 16px; padding: 12px 14px; background: rgba(255, 255, 255, 0.03); border-radius: 8px; font-size: 12px; color: #94a3b8;">
            <code>Quality Score = 100 - (0.40 * Missing% + 0.35 * Duplicate% + 0.25 * Inconsistency%)</code>
          </div>
        </div>

        <!-- Recent Cleaning Transformations History -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Cleaning Activity Trail</h2>
              <p class="panel-subtitle">${activeDataset?.transformationHistory.length ?? 0} operations applied to current dataset</p>
            </div>
            <button id="overview-view-history" class="btn-sm btn-outline">Transformation Studio →</button>
          </div>

          <div class="timeline-list">
            ${(activeDataset?.transformationHistory.length ?? 0) === 0 ? `
              <div class="empty-state-card">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
                </svg>
                <div class="empty-title">No cleaning operations applied yet</div>
                <div class="empty-desc">Click "1-Click Auto Clean" or open Cleaning Studio to resolve duplicates, missing values, and anomalies.</div>
              </div>
            ` : activeDataset!.transformationHistory.slice(-5).reverse().map(step => `
              <div class="timeline-item">
                <div class="timeline-icon">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div class="timeline-body">
                  <div class="timeline-title">${step.description}</div>
                  <div class="timeline-meta">${step.timestamp} • ${step.affectedRowsCount} row(s) impacted</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Sample Datasets Quick Switcher -->
      <div class="section-title">Preloaded Messy Enterprise Datasets</div>
      <div class="sample-cards-grid">
        ${this.appState.datasets.map(ds => `
          <div class="sample-card ${ds.id === this.appState.activeDatasetId ? 'sample-card-active' : ''}" data-id="${ds.id}">
            <div class="sample-card-header">
              <span class="sample-tag">${ds.source.toUpperCase()}</span>
              <span class="badge ${ds.cleanedQuality.overall >= 80 ? 'badge-success' : 'badge-warning'}">
                Score: ${ds.cleanedQuality.overall}%
              </span>
            </div>
            <h3 class="sample-name">${ds.name}</h3>
            <p class="sample-desc">${ds.rawRows.length} raw records with edge cases: duplicates, nulls, and formatting mismatches.</p>
            <div class="sample-card-footer">
              <span style="font-size: 12px; color: #94a3b8;">${ds.columns.length} columns</span>
              <button class="btn-sm btn-primary">Select Dataset</button>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    // Hook events
    container.querySelector('#hero-btn-workspace')?.addEventListener('click', () => {
      this.appState.setView('workspace');
    });

    container.querySelector('#hero-btn-auto-clean')?.addEventListener('click', () => {
      this.appState.run1ClickAutoClean();
    });

    container.querySelector('#hero-btn-report')?.addEventListener('click', () => {
      this.appState.setView('reports');
    });

    container.querySelector('#overview-view-history')?.addEventListener('click', () => {
      this.appState.setView('transformation');
    });

    container.querySelectorAll<HTMLElement>('.sample-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.dataset.id;
        if (id) {
          this.appState.setActiveDataset(id);
        }
      });
    });

    return container;
  }
}
