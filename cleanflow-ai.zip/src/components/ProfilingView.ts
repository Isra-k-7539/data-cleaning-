import { AppState } from '../appState';

export class ProfilingView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) {
      container.innerHTML = `<div class="empty-state-card"><div class="empty-title">No dataset selected</div></div>`;
      return container;
    }

    const quality = activeDataset.cleanedQuality;
    const profile = activeDataset.cleanedProfile;
    const totalRows = activeDataset.cleanedRows.length;
    const totalCols = activeDataset.columns.length;

    // Type distribution counts
    const typeCounts: Record<string, number> = { number: 0, string: 0, date: 0, boolean: 0 };
    profile.forEach(p => {
      typeCounts[p.inferredType] = (typeCounts[p.inferredType] || 0) + 1;
    });

    const anomaliesList: { col: string; desc: string }[] = [];
    profile.forEach(p => {
      if (p.missingCount > 0) {
        anomaliesList.push({ col: p.name, desc: `${p.missingCount} missing value(s) (${p.missingPercentage}%)` });
      }
      if (p.outlierCount && p.outlierCount > 0) {
        anomaliesList.push({ col: p.name, desc: `${p.outlierCount} extreme statistical outlier(s) detected via IQR` });
      }
      if (p.inconsistenciesExamples && p.inconsistenciesExamples.length > 0) {
        p.inconsistenciesExamples.forEach(ex => {
          anomaliesList.push({ col: p.name, desc: ex });
        });
      }
    });

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Automated Data Profiling & Health Audit</h1>
          <p class="page-subtitle">Exhaustive statistical analysis, type inference, anomaly diagnostics, and quality score breakdown</p>
        </div>
        <div class="page-header-actions">
          <button id="prof-btn-clean" class="btn-primary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
            </svg>
            Clean Identified Issues
          </button>
        </div>
      </div>

      <!-- Top Metric Summary Cards -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-label">TOTAL ROWS</div>
          <div class="kpi-value">${totalRows}</div>
          <div class="kpi-subtext">Active validated records</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">TOTAL COLUMNS</div>
          <div class="kpi-value">${totalCols}</div>
          <div class="kpi-subtext">Attributes profiled</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">DATA QUALITY INDEX</div>
          <div class="kpi-value" style="color: ${quality.overall >= 80 ? '#34d399' : quality.overall >= 60 ? '#fbbf24' : '#f87171'};">
            ${quality.overall}%
          </div>
          <div class="kpi-subtext">Weighted composite score</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">MISSING CELLS</div>
          <div class="kpi-value" style="color: ${quality.missingPercentage > 0 ? '#fb7185' : '#34d399'};">
            ${profile.reduce((s, p) => s + p.missingCount, 0)}
          </div>
          <div class="kpi-subtext">${quality.missingPercentage}% overall rate</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">MEMORY FOOTPRINT</div>
          <div class="kpi-value">${(activeDataset.sizeBytes / 1024).toFixed(1)} KB</div>
          <div class="kpi-subtext">In-memory representation</div>
        </div>
      </div>

      <!-- Quality Dimensions & Scoring Model Formula -->
      <div class="dashboard-row-2col" style="margin-top: 24px;">
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Quality Dimensions Scorecard</h2>
              <p class="panel-subtitle">Transparent mathematical evaluation across 4 enterprise dimensions</p>
            </div>
          </div>

          <div class="dimension-bars">
            <div class="dimension-item">
              <div class="dim-header">
                <span class="dim-name">Completeness</span>
                <span class="dim-val">${quality.dimensions.completeness}%</span>
              </div>
              <div class="dim-bar-track">
                <div class="dim-bar-fill" style="width: ${quality.dimensions.completeness}%; background: #10B981;"></div>
              </div>
            </div>

            <div class="dimension-item">
              <div class="dim-header">
                <span class="dim-name">Uniqueness (No Duplicates)</span>
                <span class="dim-val">${quality.dimensions.uniqueness}%</span>
              </div>
              <div class="dim-bar-track">
                <div class="dim-bar-fill" style="width: ${quality.dimensions.uniqueness}%; background: #06B6D4;"></div>
              </div>
            </div>

            <div class="dimension-item">
              <div class="dim-header">
                <span class="dim-name">Consistency (Standard Formats)</span>
                <span class="dim-val">${quality.dimensions.consistency}%</span>
              </div>
              <div class="dim-bar-track">
                <div class="dim-bar-fill" style="width: ${quality.dimensions.consistency}%; background: #6366F1;"></div>
              </div>
            </div>

            <div class="dimension-item">
              <div class="dim-header">
                <span class="dim-name">Validity</span>
                <span class="dim-val">${quality.dimensions.validity}%</span>
              </div>
              <div class="dim-bar-track">
                <div class="dim-bar-fill" style="width: ${quality.dimensions.validity}%; background: #8B5CF6;"></div>
              </div>
            </div>
          </div>

          <div style="margin-top: 18px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px; font-size: 12px; color: #94a3b8;">
            <strong>Scoring Formula:</strong> <code>Quality Score = 100 - (0.40 * M + 0.35 * D + 0.25 * I)</code><br>
            Where M = Missing% (${quality.missingPercentage}%), D = Duplicate% (${quality.duplicatePercentage}%), I = Inconsistency% (${quality.inconsistencyPercentage}%).
          </div>
        </div>

        <!-- Detected Issues & Anomalies Warning Panel -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Detected Quality Issues (${anomaliesList.length})</h2>
              <p class="panel-subtitle">Immediate issues requiring remediation before downstream reporting</p>
            </div>
          </div>

          <div class="anomalies-list">
            ${anomaliesList.length === 0 ? `
              <div style="padding: 24px; text-align: center; color: #10B981; font-weight: 600;">
                ✓ Perfect Quality! No missing values, outliers, or format inconsistencies detected.
              </div>
            ` : anomaliesList.map(a => `
              <div class="anomaly-item">
                <span class="anomaly-icon">⚠</span>
                <div class="anomaly-text">
                  <strong>Column "${a.col}":</strong> ${a.desc}
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Missing Values by Column & Data Types Distribution -->
      <div class="dashboard-row-2col" style="margin-top: 24px;">
        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Missing Values Breakdown by Column</h2>
          </div>
          <div class="col-missing-list">
            ${profile.map(p => `
              <div class="col-missing-item">
                <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 4px;">
                  <span style="font-weight: 600;">${p.name} (${p.inferredType})</span>
                  <span style="color: ${p.missingCount > 0 ? '#fb7185' : '#34d399'}; font-weight: 600;">
                    ${p.missingCount} missing (${p.missingPercentage}%)
                  </span>
                </div>
                <div class="dim-bar-track">
                  <div class="dim-bar-fill" style="width: ${p.missingPercentage}%; background: ${p.missingPercentage > 0 ? '#EF4444' : '#10B981'};"></div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Data Type Distribution</h2>
          </div>
          <div style="display: flex; gap: 14px; flex-wrap: wrap; margin-top: 10px;">
            <div class="type-stat-card">
              <span class="type-stat-val" style="color: #60a5fa;">${typeCounts.number || 0}</span>
              <span class="type-stat-label">Numerical</span>
            </div>
            <div class="type-stat-card">
              <span class="type-stat-val" style="color: #a78bfa;">${typeCounts.string || 0}</span>
              <span class="type-stat-label">Categorical/Text</span>
            </div>
            <div class="type-stat-card">
              <span class="type-stat-val" style="color: #34d399;">${typeCounts.date || 0}</span>
              <span class="type-stat-label">Date/Time</span>
            </div>
            <div class="type-stat-card">
              <span class="type-stat-val" style="color: #fbbf24;">${typeCounts.boolean || 0}</span>
              <span class="type-stat-label">Boolean</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Detailed Column Statistical Analysis Table -->
      <div class="panel" style="margin-top: 24px;">
        <div class="panel-header">
          <div>
            <h2 class="panel-title">Exhaustive Column-Level Statistical Summary</h2>
            <p class="panel-subtitle">Mean, median, standard deviation, quartiles, and top category frequencies</p>
          </div>
        </div>

        <div class="table-scroll-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>Column</th>
                <th>Type</th>
                <th>Missing</th>
                <th>Uniques</th>
                <th>Min / Max</th>
                <th>Mean / Median</th>
                <th>Std Dev</th>
                <th>Outliers (IQR)</th>
                <th>Distribution / Samples</th>
              </tr>
            </thead>
            <tbody>
              ${profile.map(p => `
                <tr>
                  <td style="font-weight: 700; color: #f8fafc;">${p.name}</td>
                  <td><span class="type-chip type-${p.inferredType}">${p.inferredType}</span></td>
                  <td style="color: ${p.missingCount > 0 ? '#fb7185' : '#34d399'}; font-weight: 600;">
                    ${p.missingCount} (${p.missingPercentage}%)
                  </td>
                  <td>${p.uniqueCount}</td>
                  <td>
                    ${p.min !== undefined ? `${p.min} / ${p.max}` : '—'}
                  </td>
                  <td>
                    ${p.mean !== undefined ? `${p.mean} / ${p.median}` : '—'}
                  </td>
                  <td>${p.stdDev !== undefined ? p.stdDev : '—'}</td>
                  <td>
                    ${p.outlierCount && p.outlierCount > 0 ? `<span class="badge badge-error">${p.outlierCount} outliers</span>` : '<span style="color: #64748b;">None</span>'}
                  </td>
                  <td style="font-size: 12px; color: #94a3b8; max-width: 250px;">
                    ${p.topCategories && p.topCategories.length > 0 ? p.topCategories.slice(0, 2).map(c => `"${c.value}" (${c.count})`).join(', ') : p.sampleValues.slice(0, 3).join(', ')}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    container.querySelector('#prof-btn-clean')?.addEventListener('click', () => {
      this.appState.setView('cleaning');
    });

    return container;
  }
}
