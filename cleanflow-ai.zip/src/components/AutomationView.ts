import { AppState } from '../appState';

export class AutomationView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const templates = this.appState.pipelineTemplates;
    const jobs = this.appState.automationJobs;
    const activeDataset = this.appState.getActiveDataset();

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Cleaning Pipeline Templates & Automation Scheduler</h1>
          <p class="page-subtitle">Standardize recurring data engineering workflows with 1-click industry templates and scheduled job automations</p>
        </div>
        <div class="page-header-actions">
          <button id="btn-create-job" class="btn-primary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Schedule New Job
          </button>
        </div>
      </div>

      <!-- 1-Click Pipeline Templates Section -->
      <div class="section-title">Predefined 1-Click Cleaning Pipeline Templates</div>
      <div class="sample-cards-grid">
        ${templates.map(tpl => `
          <div class="sample-card">
            <div class="sample-card-header">
              <span class="sample-tag">${tpl.category.toUpperCase()} PIPELINE</span>
              <span class="badge badge-info">${tpl.steps.length} Steps</span>
            </div>
            <h3 class="sample-name" style="margin-top: 8px;">${tpl.name}</h3>
            <p class="sample-desc">${tpl.description}</p>
            <div style="margin: 12px 0; font-size: 12px; color: #a5b4fc; background: rgba(99, 102, 241, 0.08); padding: 8px 12px; border-radius: 6px;">
              <strong>Included Operations:</strong>
              <ul style="margin: 4px 0 0 16px; padding: 0;">
                ${tpl.steps.slice(0, 3).map(s => `<li>${s.description}</li>`).join('')}
                ${tpl.steps.length > 3 ? `<li>+ ${tpl.steps.length - 3} more...</li>` : ''}
              </ul>
            </div>
            <div class="sample-card-footer">
              <button class="btn-primary w-full btn-run-template" data-template-id="${tpl.id}">
                Apply Template to "${activeDataset?.name.slice(0, 18) ?? 'Active'}..."
              </button>
            </div>
          </div>
        `).join('')}
      </div>

      <!-- Recurring Automation Jobs Section -->
      <div class="panel" style="margin-top: 32px;">
        <div class="panel-header">
          <div>
            <h2 class="panel-title">Active Recurring Cleaning Jobs (${jobs.length})</h2>
            <p class="panel-subtitle">Configured pipelines scheduled to automatically clean data and deliver executive reports</p>
          </div>
        </div>

        <div class="table-scroll-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>Job Name</th>
                <th>Target Dataset</th>
                <th>Template Recipe</th>
                <th>Frequency</th>
                <th>Next Run</th>
                <th>Last Run Status</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              ${jobs.map(job => `
                <tr>
                  <td style="font-weight: 700; color: #f8fafc;">${job.name}</td>
                  <td>${job.datasetName}</td>
                  <td style="color: #818cf8; font-size: 12px;">${job.templateName}</td>
                  <td><span class="badge badge-info">${job.frequency}</span></td>
                  <td style="color: #94a3b8; font-size: 12px;">${job.nextRun}</td>
                  <td>
                    <span style="color: ${job.lastRunStatus === 'Success' ? '#34d399' : '#fb7185'}; font-weight: 600;">
                      ● ${job.lastRunStatus ?? 'Pending'}
                    </span>
                    <span style="font-size: 11px; color: #64748b; margin-left: 4px;">(${job.recordsCleaned ?? 0} cleaned)</span>
                  </td>
                  <td>
                    <span class="badge ${job.status === 'Active' ? 'badge-success' : 'badge-warning'}">
                      ${job.status}
                    </span>
                  </td>
                  <td>
                    <button class="btn-sm btn-primary btn-run-job" data-job-id="${job.id}">
                      Run Now
                    </button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    // Hook template run buttons
    container.querySelectorAll<HTMLButtonElement>('.btn-run-template').forEach(btn => {
      btn.addEventListener('click', () => {
        const tplId = btn.dataset.templateId;
        if (tplId) {
          this.appState.runTemplate(tplId);
          alert('Template successfully applied! Switch to "Reports" or "Transformation Studio" to review the results.');
        }
      });
    });

    // Hook run job buttons
    container.querySelectorAll<HTMLButtonElement>('.btn-run-job').forEach(btn => {
      btn.addEventListener('click', () => {
        const jobId = btn.dataset.jobId;
        const job = this.appState.automationJobs.find(j => j.id === jobId);
        if (job) {
          // Find matching template and run
          const tpl = this.appState.pipelineTemplates.find(t => t.name === job.templateName) || this.appState.pipelineTemplates[0];
          this.appState.runTemplate(tpl.id);
          job.lastRunStatus = 'Success';
          job.lastRunTimestamp = new Date().toLocaleTimeString();
          alert(`Job "${job.name}" triggered and executed successfully!`);
          this.appState.notify();
        }
      });
    });

    // Create job trigger
    container.querySelector('#btn-create-job')?.addEventListener('click', () => {
      const jobName = prompt('Enter Automation Job Name:', 'Weekly Financial Reconciliation');
      if (!jobName) return;

      this.appState.automationJobs.push({
        id: `job-${Date.now()}`,
        name: jobName,
        datasetName: activeDataset?.name || 'Current Dataset',
        templateName: this.appState.pipelineTemplates[0].name,
        frequency: 'Weekly',
        nextRun: '2026-11-17 03:00 AM',
        status: 'Active',
        lastRunStatus: 'Success',
        recordsCleaned: activeDataset?.cleanedRows.length || 0
      });
      this.appState.notify();
    });

    return container;
  }
}
