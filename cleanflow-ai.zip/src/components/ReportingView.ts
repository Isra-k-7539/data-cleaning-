import { AppState } from '../appState';
import { ReportGenerator } from '../services/reportGenerator';

export class ReportingView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) {
      container.innerHTML = `<div class="empty-state-card"><div class="empty-title">No dataset selected</div></div>`;
      return container;
    }

    const rows = activeDataset.cleanedRows;
    const columns = activeDataset.columns;
    const profile = activeDataset.cleanedProfile;
    const rawScore = activeDataset.rawQuality.overall;
    const cleanScore = activeDataset.cleanedQuality.overall;

    const rawMissing = activeDataset.rawProfile.reduce((s, p) => s + p.missingCount, 0);
    const cleanMissing = profile.reduce((s, p) => s + p.missingCount, 0);
    const dupsRemoved = activeDataset.rawRows.length - activeDataset.cleanedRows.length;

    // Pick top numerical columns for histogram / scatter
    const numCols = profile.filter(p => p.inferredType === 'number');
    const primaryNumCol = numCols[0]?.name;
    const secondaryNumCol = numCols[1]?.name;

    // Pick top categorical column for frequency chart
    const catCols = profile.filter(p => p.inferredType === 'string');
    const primaryCatCol = catCols[0]?.name;

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Automated Executive Reporting Dashboard</h1>
          <p class="page-subtitle">Dynamic performance metrics, interactive visual distributions, and one-click report exports</p>
        </div>
        <div class="page-header-actions">
          <button id="rep-btn-view-report" class="btn-primary" style="background: linear-gradient(135deg, #6366f1, #06b6d4);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
            </svg>
            Generate Executive Audit Report
          </button>
          <button id="rep-btn-download-csv" class="btn-secondary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Export Cleaned CSV
          </button>
          <button id="rep-btn-download-json" class="btn-outline">
            Export JSON
          </button>
        </div>
      </div>

      <!-- Top KPI Row -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-label">TOTAL CLEAN RECORDS</div>
          <div class="kpi-value">${rows.length}</div>
          <div class="kpi-subtext">Verified rows</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-label">QUALITY SCORE GAIN</div>
          <div class="kpi-value" style="color: #34d399;">
            ${cleanScore}%
            <span style="font-size: 13px; font-weight: 600; color: #818cf8;">(${cleanScore - rawScore >= 0 ? `+${cleanScore - rawScore}` : cleanScore - rawScore}%)</span>
          </div>
          <div class="kpi-subtext">Baseline: ${rawScore}%</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-label">DUPLICATES REMOVED</div>
          <div class="kpi-value" style="color: #38bdf8;">${dupsRemoved}</div>
          <div class="kpi-subtext">Rows eliminated</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-label">MISSING RESOLVED</div>
          <div class="kpi-value" style="color: #fbbf24;">${Math.max(0, rawMissing - cleanMissing)}</div>
          <div class="kpi-subtext">Imputed via Median/Mode</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-label">PROCESSING LATENCY</div>
          <div class="kpi-value" style="color: #a78bfa;">< 45ms</div>
          <div class="kpi-subtext">Deterministic engine</div>
        </div>
      </div>

      <!-- Charts Section -->
      <div class="dashboard-row-2col" style="margin-top: 24px;">
        <!-- Chart 1: Data Quality Comparison (Before vs After) -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Data Quality: Raw Baseline vs Cleaned</h2>
              <p class="panel-subtitle">Comparing individual quality dimensions before and after preparation</p>
            </div>
          </div>
          <div class="chart-container" style="height: 260px; display: flex; align-items: flex-end; justify-content: space-around; padding: 20px 10px;">
            ${[
              { label: 'Overall Index', raw: rawScore, clean: cleanScore },
              { label: 'Completeness', raw: activeDataset.rawQuality.dimensions.completeness, clean: activeDataset.cleanedQuality.dimensions.completeness },
              { label: 'Uniqueness', raw: activeDataset.rawQuality.dimensions.uniqueness, clean: activeDataset.cleanedQuality.dimensions.uniqueness },
              { label: 'Consistency', raw: activeDataset.rawQuality.dimensions.consistency, clean: activeDataset.cleanedQuality.dimensions.consistency }
            ].map(item => `
              <div style="display: flex; flex-direction: column; align-items: center; gap: 8px;">
                <div style="display: flex; align-items: flex-end; gap: 6px; height: 180px;">
                  <!-- Raw Bar -->
                  <div style="width: 24px; height: ${item.raw * 1.6}px; background: #475569; border-radius: 4px 4px 0 0;" title="Raw: ${item.raw}%">
                    <div style="font-size: 10px; color: #cbd5e0; text-align: center; margin-top: -16px;">${item.raw}%</div>
                  </div>
                  <!-- Clean Bar -->
                  <div style="width: 24px; height: ${item.clean * 1.6}px; background: #6366F1; border-radius: 4px 4px 0 0;" title="Cleaned: ${item.clean}%">
                    <div style="font-size: 10px; color: #818cf8; font-weight: 700; text-align: center; margin-top: -16px;">${item.clean}%</div>
                  </div>
                </div>
                <span style="font-size: 11px; color: #94a3b8; font-weight: 600;">${item.label}</span>
              </div>
            `).join('')}
          </div>
          <div style="display: flex; justify-content: center; gap: 16px; margin-top: 10px; font-size: 12px;">
            <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 12px; height: 12px; background: #475569; border-radius: 2px;"></span> Raw Baseline</span>
            <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 12px; height: 12px; background: #6366F1; border-radius: 2px;"></span> Cleaned Dataset</span>
          </div>
        </div>

        <!-- Chart 2: Top Categorical Distribution Breakdown -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Categorical Distribution: ${primaryCatCol ?? 'Categories'}</h2>
              <p class="panel-subtitle">Frequency Breakdown across top standardized records</p>
            </div>
          </div>
          <div class="cat-chart-wrap" style="padding: 10px 0;">
            ${this.renderCategoryChart(profile, primaryCatCol)}
          </div>
        </div>
      </div>

      <!-- Charts Row 2: Numerical Distributions & Scatter -->
      <div class="dashboard-row-2col" style="margin-top: 24px;">
        <!-- Chart 3: Numerical Distribution Histogram -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Numerical Distribution: ${primaryNumCol ?? 'Metrics'}</h2>
              <p class="panel-subtitle">Histogram buckets showing density and central tendency</p>
            </div>
          </div>
          <div class="chart-container" style="height: 240px; padding: 10px 0;">
            ${this.renderHistogram(rows, primaryNumCol)}
          </div>
        </div>

        <!-- Chart 4: Correlation & Scatter Plot -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <h2 class="panel-title">Relationship: ${primaryNumCol ?? 'X'} vs ${secondaryNumCol ?? 'Record Index'}</h2>
              <p class="panel-subtitle">Scatter distribution tracking variance and trend line</p>
            </div>
          </div>
          <div class="chart-container" style="height: 240px; padding: 10px 0;">
            ${this.renderScatterPlot(rows, primaryNumCol, secondaryNumCol)}
          </div>
        </div>
      </div>
    `;

    // Hook export buttons
    container.querySelector('#rep-btn-view-report')?.addEventListener('click', () => {
      const htmlContent = ReportGenerator.generateExecutiveHTMLReport(activeDataset);
      const reportWindow = window.open('', '_blank');
      if (reportWindow) {
        reportWindow.document.write(htmlContent);
        reportWindow.document.close();
      } else {
        alert('Pop-up blocked. Please allow popups or download report file.');
      }
    });

    container.querySelector('#rep-btn-download-csv')?.addEventListener('click', () => {
      const csv = ReportGenerator.exportToCSV(activeDataset);
      ReportGenerator.downloadFile(csv, `${activeDataset.name.toLowerCase().replace(/\s+/g, '_')}_cleaned.csv`, 'text/csv');
    });

    container.querySelector('#rep-btn-download-json')?.addEventListener('click', () => {
      const jsonStr = ReportGenerator.exportToJSON(activeDataset);
      ReportGenerator.downloadFile(jsonStr, `${activeDataset.name.toLowerCase().replace(/\s+/g, '_')}_cleaned.json`, 'application/json');
    });

    return container;
  }

  private renderCategoryChart(profile: any[], catColName?: string): string {
    if (!catColName) {
      return `<div style="color: #94a3b8; text-align: center; padding: 30px;">No categorical column detected in dataset</div>`;
    }
    const prof = profile.find(p => p.name === catColName);
    const topCats = prof?.topCategories ?? [];

    if (topCats.length === 0) {
      return `<div style="color: #94a3b8; text-align: center; padding: 30px;">No category frequencies available</div>`;
    }

    const maxCount = Math.max(...topCats.map((c: any) => c.count), 1);
    const colors = ['#6366F1', '#06B6D4', '#10B981', '#F59E0B', '#EC4899'];

    return `
      <div style="display: flex; flex-direction: column; gap: 14px; padding: 8px 14px;">
        ${topCats.map((cat: any, idx: number) => {
          const widthPct = Math.round((cat.count / maxCount) * 100);
          const color = colors[idx % colors.length];
          return `
            <div>
              <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 600; margin-bottom: 4px;">
                <span style="color: #f8fafc;">${cat.value}</span>
                <span style="color: ${color};">${cat.count} records (${cat.percentage}%)</span>
              </div>
              <div style="height: 10px; background: #1e293b; border-radius: 9999px; overflow: hidden;">
                <div style="height: 100%; width: ${widthPct}%; background: ${color}; border-radius: 9999px;"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  private renderHistogram(rows: any[], numColName?: string): string {
    if (!numColName) {
      return `<div style="color: #94a3b8; text-align: center; padding: 40px;">No numerical column available for histogram</div>`;
    }
    const values = rows.map(r => Number(r[numColName])).filter(v => !isNaN(v)).sort((a, b) => a - b);
    if (values.length === 0) return `<div style="color: #94a3b8; text-align: center; padding: 40px;">No values</div>`;

    const min = values[0];
    const max = values[values.length - 1];
    const bucketsCount = 6;
    const bucketSize = (max - min) / bucketsCount || 1;

    const buckets = Array.from({ length: bucketsCount }, () => 0);
    values.forEach(v => {
      const idx = Math.min(bucketsCount - 1, Math.floor((v - min) / bucketSize));
      buckets[idx]++;
    });

    const maxBucketCount = Math.max(...buckets, 1);

    return `
      <div style="display: flex; align-items: flex-end; justify-content: space-around; height: 180px; padding: 10px 20px;">
        ${buckets.map((count, idx) => {
          const heightPct = Math.round((count / maxBucketCount) * 150);
          const rangeStart = Math.round(min + idx * bucketSize);
          const rangeEnd = Math.round(min + (idx + 1) * bucketSize);
          return `
            <div style="display: flex; flex-direction: column; align-items: center; gap: 6px;">
              <div style="font-size: 10px; color: #818cf8; font-weight: 700;">${count}</div>
              <div style="width: 36px; height: ${heightPct}px; background: linear-gradient(180deg, #6366f1 0%, #312e81 100%); border-radius: 4px 4px 0 0;" title="${count} items in range [${rangeStart} - ${rangeEnd}]"></div>
              <div style="font-size: 9px; color: #94a3b8; white-space: nowrap;">${rangeStart}</div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  private renderScatterPlot(rows: any[], xCol?: string, yCol?: string): string {
    if (!xCol) {
      return `<div style="color: #94a3b8; text-align: center; padding: 40px;">No numerical column for scatter plot</div>`;
    }

    const points = rows.map((r, i) => {
      const x = Number(r[xCol]) || 0;
      const y = yCol ? (Number(r[yCol]) || 0) : i;
      return { x, y };
    });

    const xVals = points.map(p => p.x);
    const yVals = points.map(p => p.y);
    const minX = Math.min(...xVals);
    const maxX = Math.max(...xVals) || 1;
    const minY = Math.min(...yVals);
    const maxY = Math.max(...yVals) || 1;

    return `
      <div style="position: relative; width: 100%; height: 180px; background: rgba(0,0,0,0.2); border-radius: 8px; border: 1px dashed #334155; margin: 10px 0; overflow: hidden;">
        ${points.map((p, idx) => {
          const leftPct = Math.max(5, Math.min(95, ((p.x - minX) / (maxX - minX || 1)) * 90 + 5));
          const bottomPct = Math.max(5, Math.min(95, ((p.y - minY) / (maxY - minY || 1)) * 90 + 5));
          return `
            <div style="position: absolute; left: ${leftPct}%; bottom: ${bottomPct}%; width: 8px; height: 8px; background: #38bdf8; border-radius: 50%; box-shadow: 0 0 8px #38bdf8; transform: translate(-50%, 50%); cursor: pointer;"
              title="Record #${idx + 1}: ${xCol}=${p.x}${yCol ? `, ${yCol}=${p.y}` : ''}"></div>
          `;
        }).join('')}
      </div>
      <div style="display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8; padding: 0 10px;">
        <span>Min: ${minX}</span>
        <span style="color: #38bdf8; font-weight: 600;">Hover over nodes to inspect coordinates</span>
        <span>Max: ${maxX}</span>
      </div>
    `;
  }
}
