import { AppState } from '../appState';
import { ViewType } from '../types';

export class SidebarComponent {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const aside = document.createElement('aside');
    aside.className = 'sidebar';

    const current = this.appState.currentView;
    const activeDataset = this.appState.getActiveDataset();

    const navItems: { id: ViewType; label: string; iconSvg: string; badge?: string }[] = [
      {
        id: 'overview',
        label: 'Overview',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>`
      },
      {
        id: 'workspace',
        label: 'Data Workspace',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 22h14a2 2 0 0 0 2-2V7.5L14.5 2H6a2 2 0 0 0-2 2v4"/><polyline points="14 2 14 8 20 8"/><path d="M2 15h10"/><path d="m9 18 3-3-3-3"/></svg>`,
        badge: `${activeDataset?.cleanedRows.length ?? 0}`
      },
      {
        id: 'profiling',
        label: 'Data Profiling',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>`,
        badge: `${activeDataset?.cleanedQuality.overall ?? 0}%`
      },
      {
        id: 'cleaning',
        label: 'Cleaning Studio',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>`
      },
      {
        id: 'transformation',
        label: 'Transformation Studio',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>`,
        badge: `${activeDataset?.transformationHistory.length ?? 0}`
      },
      {
        id: 'reports',
        label: 'Reports & Dashboards',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`
      },
      {
        id: 'automation',
        label: 'Automation & Jobs',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
        badge: `${this.appState.automationJobs.length}`
      },
      {
        id: '3d_view',
        label: '3D Point Cloud',
        iconSvg: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>`
      }
    ];

    aside.innerHTML = `
      <div class="sidebar-nav-group">
        <div class="sidebar-section-title">NAVIGATION</div>
        <nav class="sidebar-nav">
          ${navItems.map(item => `
            <button class="nav-item ${current === item.id ? 'active' : ''}" data-view="${item.id}">
              <span class="nav-icon">${item.iconSvg}</span>
              <span class="nav-label">${item.label}</span>
              ${item.badge ? `<span class="nav-badge">${item.badge}</span>` : ''}
            </button>
          `).join('')}
        </nav>
      </div>

      <div class="sidebar-footer">
        <div class="sidebar-dataset-card">
          <div class="sidebar-dataset-title">${activeDataset?.name ?? 'No Dataset'}</div>
          <div class="sidebar-dataset-meta">
            <span>${activeDataset?.cleanedRows.length ?? 0} rows</span>
            <span>•</span>
            <span>${activeDataset?.columns.length ?? 0} cols</span>
          </div>
          <div class="quality-mini-bar-track">
            <div class="quality-mini-bar-fill" style="width: ${activeDataset?.cleanedQuality.overall ?? 0}%;"></div>
          </div>
        </div>

        <button id="sidebar-auto-clean" class="btn-primary w-full" style="font-size: 13px; padding: 10px 14px;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
          </svg>
          1-Click Auto Clean
        </button>
      </div>
    `;

    aside.querySelectorAll<HTMLButtonElement>('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view as ViewType;
        if (view) this.appState.setView(view);
      });
    });

    const autoCleanBtn = aside.querySelector('#sidebar-auto-clean');
    autoCleanBtn?.addEventListener('click', () => {
      this.appState.run1ClickAutoClean();
    });

    return aside;
  }
}
