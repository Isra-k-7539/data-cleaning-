import * as THREE from 'three';
import { AppState } from '../appState';

export class ThreeDataVisualizer {
  private appState = AppState.getInstance();
  private container: HTMLElement | null = null;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private animationFrameId: number | null = null;

  private pointsGroup: THREE.Group | null = null;
  private hologramCore: THREE.Group | null = null;

  // Damped camera controls
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private targetRotation = { x: 0.3, y: 0.5 };
  private currentRotation = { x: 0.3, y: 0.5 };

  render(): HTMLElement {
    const root = document.createElement('div');
    root.className = 'three-visualizer-root';

    root.innerHTML = `
      <div id="three-canvas-container" class="three-canvas-container"></div>

      <!-- Viewport Floating Control Dock -->
      <div class="three-control-dock">
        <div class="three-dock-header">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span class="three-pulse-dot"></span>
            <span style="font-weight: 800; font-size: 13px; color: #f8fafc; letter-spacing: 0.5px;">3D DATA CONSTELLATION</span>
          </div>
          <button id="btn-close-3d" class="btn-sm btn-outline" style="padding: 4px 8px; font-size: 11px;">
            Exit 3D View ✕
          </button>
        </div>

        <div style="font-size: 12px; color: #94a3b8; margin: 8px 0;">
          Spatial Point Cloud: <strong>${this.appState.getActiveDataset()?.name ?? 'Dataset'}</strong>
        </div>

        <div style="display: flex; gap: 10px; font-size: 11px; color: #cbd5e0; margin-bottom: 8px;">
          <span>● Records: <strong>${this.appState.getActiveDataset()?.cleanedRows.length ?? 0}</strong></span>
          <span>● Clustered Features: <strong>3D Space</strong></span>
        </div>

        <div style="font-size: 11px; color: #818cf8; background: rgba(99, 102, 241, 0.1); padding: 6px 10px; border-radius: 6px;">
          💡 Drag mouse to orbit. Scroll wheel to zoom. Points represent individual dataset rows.
        </div>
      </div>
    `;

    setTimeout(() => {
      const containerEl = root.querySelector<HTMLElement>('#three-canvas-container');
      if (containerEl) {
        this.initThree(containerEl);
      }
    }, 20);

    root.querySelector('#btn-close-3d')?.addEventListener('click', () => {
      this.destroy();
      this.appState.setView('overview');
    });

    return root;
  }

  private initThree(container: HTMLElement) {
    this.container = container;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b0f19);
    this.scene.fog = new THREE.FogExp2(0x0b0f19, 0.04);

    // Camera
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    this.camera.position.set(0, 3, 10);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    container.appendChild(this.renderer.domElement);

    // Studio PBR Lighting
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x111827, 2.5);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0x818cf8, 3.0);
    dirLight.position.set(5, 10, 7);
    this.scene.add(dirLight);

    const pointLight = new THREE.PointLight(0x06b6d4, 4, 15);
    pointLight.position.set(0, 0, 0);
    this.scene.add(pointLight);

    // Build Central Hologram Core (Composite 3-12 part procedural model)
    this.hologramCore = this.createHologramCore();
    this.scene.add(this.hologramCore);

    // Build Data Points Cluster from active dataset rows
    this.pointsGroup = this.createDataPoints();
    this.scene.add(this.pointsGroup);

    // Grid Plane / Ground
    const grid = new THREE.GridHelper(20, 20, 0x334155, 0x1e293b);
    grid.position.y = -2;
    this.scene.add(grid);

    // Event listeners
    this.setupInteractions(container);

    // Animation Loop
    let lastTime = performance.now();
    const animate = (time: number) => {
      this.animationFrameId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      // Damped rotation
      const k = 8.0;
      const alpha = 1 - Math.exp(-k * dt);
      this.currentRotation.x += (this.targetRotation.x - this.currentRotation.x) * alpha;
      this.currentRotation.y += (this.targetRotation.y - this.currentRotation.y) * alpha;

      if (this.pointsGroup) {
        this.pointsGroup.rotation.x = this.currentRotation.x;
        this.pointsGroup.rotation.y = this.currentRotation.y + time * 0.0002;
      }

      if (this.hologramCore) {
        this.hologramCore.rotation.y = time * 0.0008;
        this.hologramCore.rotation.z = Math.sin(time * 0.001) * 0.1;
      }

      this.camera?.lookAt(0, 0, 0);
      this.renderer?.render(this.scene!, this.camera!);
    };

    animate(performance.now());
  }

  private createHologramCore(): THREE.Group {
    const group = new THREE.Group();

    // Central pulsing core sphere
    const sphereGeo = new THREE.SphereGeometry(0.8, 32, 32);
    const sphereMat = new THREE.MeshStandardMaterial({
      color: 0x6366f1,
      roughness: 0.2,
      metalness: 0.8,
      emissive: 0x4338ca,
      emissiveIntensity: 0.6,
      wireframe: true
    });
    const coreMesh = new THREE.Mesh(sphereGeo, sphereMat);
    group.add(coreMesh);

    // Outer nested gimbal ring 1
    const ringGeo1 = new THREE.TorusGeometry(1.4, 0.03, 16, 64);
    const ringMat1 = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      metalness: 0.9,
      roughness: 0.1,
      emissive: 0x0891b2,
      emissiveIntensity: 0.4
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 4;
    group.add(ring1);

    // Outer nested gimbal ring 2
    const ringGeo2 = new THREE.TorusGeometry(1.8, 0.03, 16, 64);
    const ringMat2 = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      metalness: 0.9,
      roughness: 0.1,
      emissive: 0x7e22ce,
      emissiveIntensity: 0.4
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.y = Math.PI / 3;
    group.add(ring2);

    return group;
  }

  private createDataPoints(): THREE.Group {
    const group = new THREE.Group();
    const dataset = this.appState.getActiveDataset();
    if (!dataset || dataset.cleanedRows.length === 0) return group;

    const rows = dataset.cleanedRows;
    const numCols = dataset.cleanedProfile.filter(p => p.inferredType === 'number');
    const colX = numCols[0]?.name;
    const colY = numCols[1]?.name;
    const colZ = numCols[2]?.name;

    const colors = [0x6366f1, 0x06b6d4, 0x10b981, 0xf59e0b, 0xec4899, 0xa855f7];

    const sphereGeo = new THREE.SphereGeometry(0.12, 16, 16);

    rows.forEach((row, i) => {
      let x = colX && row[colX] !== null ? Number(row[colX]) : (i % 5) - 2;
      let y = colY && row[colY] !== null ? Number(row[colY]) : Math.sin(i) * 2;
      let z = colZ && row[colZ] !== null ? Number(row[colZ]) : Math.cos(i) * 2;

      // Normalize scale for 3D viewing
      const radius = 3.5 + (i % 3) * 0.8;
      const theta = (i / rows.length) * Math.PI * 2;
      const phi = Math.sin(i * 1.5) * 1.2;

      const px = radius * Math.cos(theta) * Math.cos(phi);
      const py = radius * Math.sin(phi);
      const pz = radius * Math.sin(theta) * Math.cos(phi);

      const color = colors[i % colors.length];
      const mat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.3,
        metalness: 0.7,
        emissive: color,
        emissiveIntensity: 0.4
      });

      const mesh = new THREE.Mesh(sphereGeo, mat);
      mesh.position.set(px, py, pz);
      group.add(mesh);
    });

    return group;
  }

  private setupInteractions(container: HTMLElement) {
    container.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.targetRotation.y += deltaX * 0.006;
      this.targetRotation.x += deltaY * 0.006;

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    container.addEventListener('wheel', (e) => {
      if (this.camera) {
        this.camera.position.z = Math.max(3, Math.min(25, this.camera.position.z + e.deltaY * 0.01));
      }
    });

    window.addEventListener('resize', this.onWindowResize);
  }

  private onWindowResize = () => {
    if (!this.container || !this.camera || !this.renderer) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  destroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer && this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
    this.renderer?.dispose();
  }
}
