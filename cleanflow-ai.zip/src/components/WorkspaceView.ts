import { AppState } from '../appState';
import { SAMPLE_DATASETS } from '../data/sampleDatasets';
import { DataEngine } from '../services/dataEngine';

export class WorkspaceView {
  private appState = AppState.getInstance();
  private activeTab: 'cleaned' | 'raw' = 'cleaned';

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    const rowsToDisplay = this.activeTab === 'cleaned'
      ? (activeDataset?.cleanedRows ?? [])
      : (activeDataset?.rawRows ?? []);
    const columns = activeDataset?.columns ?? [];

    // Filter by search query if any
    const query = this.appState.searchFilter.toLowerCase().trim();
    const filteredRows = query
      ? rowsToDisplay.filter(row => {
          return Object.values(row).some(v => v !== null && v !== undefined && String(v).toLowerCase().includes(query));
        })
      : rowsToDisplay;

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Data Workspace & Smart Upload</h1>
          <p class="page-subtitle">Upload custom datasets or inspect active records with live anomaly detection</p>
        </div>
        <div class="page-header-actions">
          <button id="ws-btn-clean" class="btn-primary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
            </svg>
            Clean This Dataset
          </button>
          <button id="ws-btn-profile" class="btn-outline">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>
            </svg>
            View Data Profile
          </button>
        </div>
      </div>

      <!-- Drag & Drop Upload Zone -->
      <div class="upload-dropzone" id="upload-zone">
        <input type="file" id="file-input" accept=".csv,.json,.txt,.tsv" style="display: none;" />
        <div class="upload-icon-circle">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
        </div>
        <div class="upload-title">Drop your messy CSV, JSON, or TSV file here</div>
        <div class="upload-desc">Supports auto-detection of column types, delimiters, quotes, and empty values up to 50MB</div>
        <button id="btn-browse-file" class="btn-primary" style="margin-top: 14px;">Browse Files from Computer</button>
      </div>

      <!-- Preloaded Enterprise Sample Datasets -->
      <div class="panel" style="margin-top: 24px;">
        <div class="panel-header">
          <div>
            <h2 class="panel-title">Explore Realistic Sample Datasets</h2>
            <p class="panel-subtitle">Preloaded with real-world anomalies: duplicates, nulls, negative numbers, and casing issues</p>
          </div>
        </div>
        <div class="sample-pills-row">
          ${SAMPLE_DATASETS.map(sample => `
            <button class="sample-pill-btn ${activeDataset?.name === sample.name ? 'active' : ''}" data-sample-id="${sample.id}">
              <span class="sample-pill-category">${sample.category}</span>
              <span class="sample-pill-name">${sample.name}</span>
              <span class="sample-pill-rows">${sample.rows.length} rows</span>
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Dataset Preview Table & Inspection Studio -->
      <div class="panel" style="margin-top: 24px;">
        <div class="panel-header" style="flex-wrap: wrap; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 14px;">
            <!-- Raw vs Cleaned Tab Toggle -->
            <div class="tab-pill-group">
              <button class="tab-pill ${this.activeTab === 'cleaned' ? 'active' : ''}" id="tab-cleaned">
                Cleaned Data (${activeDataset?.cleanedRows.length ?? 0})
              </button>
              <button class="tab-pill ${this.activeTab === 'raw' ? 'active' : ''}" id="tab-raw">
                Raw Baseline (${activeDataset?.rawRows.length ?? 0})
              </button>
            </div>
            <span style="font-size: 13px; color: #94a3b8;">
              Showing <strong>${filteredRows.length}</strong> of ${rowsToDisplay.length} rows • <strong>${columns.length}</strong> columns
            </span>
          </div>

          <div style="display: flex; align-items: center; gap: 10px;">
            <div class="table-legend">
              <span class="legend-chip legend-null">NULL / Missing</span>
              <span class="legend-chip legend-num">Number</span>
              <span class="legend-chip legend-date">Date</span>
            </div>
          </div>
        </div>

        <!-- Table Container -->
        <div class="table-scroll-container">
          ${columns.length === 0 ? `
            <div class="empty-state-card">
              <div class="empty-title">No active dataset columns</div>
              <div class="empty-desc">Upload a file or choose one of the preloaded sample datasets above.</div>
            </div>
          ` : `
            <table class="data-table">
              <thead>
                <tr>
                  <th style="width: 50px;">#</th>
                  ${columns.map(col => {
                    const prof = activeDataset?.cleanedProfile.find(p => p.name === col);
                    const typeBadge = prof?.inferredType ?? 'string';
                    return `
                      <th>
                        <div class="th-content">
                          <span class="th-name">${col}</span>
                          <span class="type-chip type-${typeBadge}">${typeBadge}</span>
                        </div>
                      </th>
                    `;
                  }).join('')}
                </tr>
              </thead>
              <tbody>
                ${filteredRows.map((row, index) => {
                  return `
                    <tr>
                      <td class="td-index">${index + 1}</td>
                      ${columns.map(col => {
                        const val = row[col];
                        const isNull = val === null || val === undefined || val === '' || val === 'NULL';
                        if (isNull) {
                          return `<td class="td-cell td-null"><span class="null-pill">NULL</span></td>`;
                        }
                        if (typeof val === 'number') {
                          return `<td class="td-cell td-number">${val.toLocaleString()}</td>`;
                        }
                        return `<td class="td-cell">${String(val)}</td>`;
                      }).join('')}
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `}
        </div>
      </div>
    `;

    // Dropzone upload logic
    const dropzone = container.querySelector('#upload-zone');
    const fileInput = container.querySelector<HTMLInputElement>('#file-input');
    const browseBtn = container.querySelector('#btn-browse-file');

    browseBtn?.addEventListener('click', () => fileInput?.click());
    dropzone?.addEventListener('click', (e) => {
      if (e.target !== browseBtn) fileInput?.click();
    });

    dropzone?.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('drag-active');
    });

    dropzone?.addEventListener('dragleave', () => {
      dropzone.classList.remove('drag-active');
    });

    dropzone?.addEventListener('drop', (e: Event) => {
      const dragEvent = e as DragEvent;
      dragEvent.preventDefault();
      dropzone.classList.remove('drag-active');
      if (dragEvent.dataTransfer && dragEvent.dataTransfer.files.length > 0) {
        this.handleFileUpload(dragEvent.dataTransfer.files[0]);
      }
    });

    fileInput?.addEventListener('change', () => {
      if (fileInput.files && fileInput.files.length > 0) {
        this.handleFileUpload(fileInput.files[0]);
      }
    });

    // Sample pills
    container.querySelectorAll<HTMLButtonElement>('.sample-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.sampleId;
        if (id) {
          this.appState.setActiveDataset(id);
        }
      });
    });

    // Tabs
    container.querySelector('#tab-cleaned')?.addEventListener('click', () => {
      this.activeTab = 'cleaned';
      this.appState.notify();
    });
    container.querySelector('#tab-raw')?.addEventListener('click', () => {
      this.activeTab = 'raw';
      this.appState.notify();
    });

    // Navigation buttons
    container.querySelector('#ws-btn-clean')?.addEventListener('click', () => {
      this.appState.setView('cleaning');
    });
    container.querySelector('#ws-btn-profile')?.addEventListener('click', () => {
      this.appState.setView('profiling');
    });

    return container;
  }

  private handleFileUpload(file: File) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) return;

      try {
        let columns: string[] = [];
        let rows: any[] = [];

        if (file.name.endsWith('.json')) {
          const parsed = DataEngine.parseJSON(text);
          columns = parsed.columns;
          rows = parsed.rows;
        } else {
          // CSV / TSV / TXT
          const parsed = DataEngine.parseCSV(text);
          columns = parsed.columns;
          rows = parsed.rows;
        }

        if (rows.length === 0) {
          alert('Uploaded file contains no rows.');
          return;
        }

        this.appState.addUploadedDataset(file.name.replace(/\.[^/.]+$/, ''), rows, columns);
      } catch (err: any) {
        alert('Failed to parse uploaded file: ' + err.message);
      }
    };
    reader.readAsText(file);
  }
}
