import { AppState } from '../appState';
import { DataEngine } from '../services/dataEngine';
import { GeminiAssistantService } from '../services/geminiService';

export class AIAssistantModal {
  private appState = AppState.getInstance();
  private messages: { sender: 'user' | 'assistant'; text: string; actions?: any[] }[] = [];
  private isThinking = false;

  constructor() {
    this.messages.push({
      sender: 'assistant',
      text: `Hello! I am your **CleanFlow AI Assistant**.\n\nI can analyze your dataset's health, explain why your quality score is low, or automatically clean your data based on natural language instructions.\n\nTry asking me:\n• _"Why does my dataset have a low quality score?"_\n• _"Remove duplicate rows and fill missing values with median"_\n• _"Standardize date formats and trim whitespace"_`
    });
  }

  render(): HTMLElement {
    const backdrop = document.createElement('div');
    backdrop.className = `ai-drawer-backdrop ${this.appState.isAIOpen ? 'open' : ''}`;

    const drawer = document.createElement('div');
    drawer.className = 'ai-drawer';

    const activeDataset = this.appState.getActiveDataset();

    drawer.innerHTML = `
      <div class="ai-drawer-header">
        <div style="display: flex; align-items: center; gap: 10px;">
          <div class="brand-icon" style="width: 32px; height: 32px; background: linear-gradient(135deg, #6366f1, #06b6d4);">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>
            </svg>
          </div>
          <div>
            <div style="font-weight: 700; font-size: 15px; color: #f8fafc;">CleanFlow AI Assistant</div>
            <div style="font-size: 11px; color: #94a3b8;">Active Context: ${activeDataset?.name.slice(0, 24) ?? 'No Dataset'}...</div>
          </div>
        </div>
        <button id="ai-btn-close" class="btn-icon" style="background: transparent; border: none; color: #94a3b8; font-size: 20px; cursor: pointer;">✕</button>
      </div>

      <!-- Quick Suggestion Pills -->
      <div class="ai-suggestions-bar">
        <button class="ai-pill-btn" data-prompt="Why does my dataset have a low quality score?">
          Why is quality score low?
        </button>
        <button class="ai-pill-btn" data-prompt="Remove duplicate rows and fill missing numerical values with median">
          Deduplicate & fill median
        </button>
        <button class="ai-pill-btn" data-prompt="Standardize all date formats and trim whitespace">
          Standardize dates & trim spaces
        </button>
      </div>

      <!-- Messages Stream -->
      <div class="ai-messages-list" id="ai-messages-list">
        ${this.messages.map(m => `
          <div class="ai-msg ${m.sender}">
            <div class="ai-msg-bubble">
              ${this.formatMarkdown(m.text)}
              ${m.actions && m.actions.length > 0 ? `
                <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.1);">
                  <button class="btn-primary w-full btn-apply-ai-plan" style="font-size: 12px; padding: 8px 12px;">
                    ⚡ Execute Generated Cleaning Plan (${m.actions.length} Steps)
                  </button>
                </div>
              ` : ''}
            </div>
          </div>
        `).join('')}
        ${this.isThinking ? `
          <div class="ai-msg assistant">
            <div class="ai-msg-bubble" style="display: flex; align-items: center; gap: 8px; color: #818cf8;">
              <span class="ai-spinner"></span>
              Analyzing dataset and generating structured plan...
            </div>
          </div>
        ` : ''}
      </div>

      <!-- Input Bar -->
      <div class="ai-input-bar">
        <input type="text" id="ai-chat-input" class="ai-chat-input" placeholder="Type instructions, e.g. 'clean duplicates and fill missing'..." />
        <button id="ai-btn-send" class="btn-primary" style="height: 42px; padding: 0 18px;">
          Send
        </button>
      </div>
    `;

    // Hook events
    drawer.querySelector('#ai-btn-close')?.addEventListener('click', () => {
      this.appState.toggleAI(false);
    });

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) this.appState.toggleAI(false);
    });

    drawer.querySelectorAll<HTMLButtonElement>('.ai-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const p = btn.dataset.prompt;
        if (p) this.sendPrompt(p);
      });
    });

    const input = drawer.querySelector<HTMLInputElement>('#ai-chat-input');
    const sendBtn = drawer.querySelector('#ai-btn-send');

    const doSend = () => {
      const val = input?.value.trim();
      if (val) {
        input!.value = '';
        this.sendPrompt(val);
      }
    };

    sendBtn?.addEventListener('click', doSend);
    input?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') doSend();
    });

    // Execute AI plan button
    drawer.querySelectorAll<HTMLButtonElement>('.btn-apply-ai-plan').forEach(btn => {
      btn.addEventListener('click', () => {
        const lastWithActions = [...this.messages].reverse().find(m => m.actions && m.actions.length > 0);
        if (lastWithActions && lastWithActions.actions) {
          this.executeAIActions(lastWithActions.actions);
        }
      });
    });

    backdrop.appendChild(drawer);

    // Scroll chat to bottom
    setTimeout(() => {
      const list = drawer.querySelector('#ai-messages-list');
      if (list) list.scrollTop = list.scrollHeight;
    }, 50);

    return backdrop;
  }

  private async sendPrompt(promptText: string) {
    this.messages.push({ sender: 'user', text: promptText });
    this.isThinking = true;
    this.appState.notify();

    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) {
      this.isThinking = false;
      this.messages.push({ sender: 'assistant', text: 'Please select or upload a dataset first.' });
      this.appState.notify();
      return;
    }

    try {
      const res = await GeminiAssistantService.queryAssistant(promptText, {
        datasetName: activeDataset.name,
        columns: activeDataset.columns,
        profile: activeDataset.cleanedProfile,
        quality: activeDataset.cleanedQuality,
        rowsSample: activeDataset.cleanedRows.slice(0, 5)
      });

      this.isThinking = false;
      this.messages.push({
        sender: 'assistant',
        text: res.answer,
        actions: res.recommendedActions
      });
      this.appState.notify();
    } catch (err: any) {
      this.isThinking = false;
      this.messages.push({
        sender: 'assistant',
        text: `Sorry, I encountered an issue: ${err.message}`
      });
      this.appState.notify();
    }
  }

  private executeAIActions(actions: any[]) {
    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) return;

    actions.forEach(a => {
      if (a.action === 'remove_duplicates') {
        this.appState.applyTransformation('remove_duplicates', a.description, (rows) => DataEngine.removeDuplicates(rows));
      } else if (a.action === 'trim_whitespace') {
        this.appState.applyTransformation('trim_whitespace', a.description, (rows) => DataEngine.trimWhitespace(rows));
      } else if (a.action === 'standardize_dates' && a.column) {
        this.appState.applyTransformation('standardize_dates', a.description, (rows) => DataEngine.standardizeDates(rows, a.column));
      } else if (a.action === 'normalize_categories' && a.column) {
        this.appState.applyTransformation('normalize_categories', a.description, (rows) => DataEngine.normalizeCategories(rows, a.column), a.column);
      } else if (a.action.startsWith('impute_') && a.column) {
        const method = a.action.replace('impute_', '') as any;
        this.appState.applyTransformation(a.action, a.description, (rows) => DataEngine.imputeMissing(rows, a.column, method), a.column);
      } else if (a.action === 'handle_outliers_iqr' && a.column) {
        this.appState.applyTransformation('handle_outliers_iqr', a.description, (rows) => DataEngine.handleOutliers(rows, a.column, 'iqr', 'cap'), a.column);
      }
    });

    this.messages.push({
      sender: 'assistant',
      text: `✓ **Successfully executed ${actions.length} cleaning operations!** The dataset quality score has been refreshed. Check the Reports or Transformation Studio to review the updated dataset.`
    });
    this.appState.notify();
  }

  private formatMarkdown(text: string): string {
    return text
      .replace(/### (.*?)\n/g, '<h4 style="margin: 8px 0 4px 0; color: #f8fafc;">$1</h4>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/_(.*?)_/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code style="background: rgba(255,255,255,0.1); padding: 2px 5px; border-radius: 4px; font-family: monospace;">$1</code>')
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n/g, '<br>');
  }
}
