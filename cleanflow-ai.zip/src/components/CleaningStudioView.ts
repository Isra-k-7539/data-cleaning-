import { AppState } from '../appState';
import { DataEngine } from '../services/dataEngine';
import { CustomRule } from '../types';

export class CleaningStudioView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) {
      container.innerHTML = `<div class="empty-state-card"><div class="empty-title">No dataset selected</div></div>`;
      return container;
    }

    const columns = activeDataset.columns;
    const profile = activeDataset.cleanedProfile;
    const rawScore = activeDataset.rawQuality.overall;
    const cleanScore = activeDataset.cleanedQuality.overall;

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Intelligent Data Cleaning Studio</h1>
          <p class="page-subtitle">Interactive rule builder for missing values, deduplication, standardization, outliers, and custom logic</p>
        </div>
        <div class="page-header-actions">
          <button id="clean-btn-auto" class="btn-primary" style="background: linear-gradient(135deg, #6366f1, #06b6d4);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
            </svg>
            1-Click Auto Clean All
          </button>
          <button id="clean-btn-undo" class="btn-secondary" ${activeDataset.undoStack.length === 0 ? 'disabled' : ''}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
            Undo (${activeDataset.undoStack.length})
          </button>
          <button id="clean-btn-reset" class="btn-outline">
            Reset to Raw
          </button>
        </div>
      </div>

      <!-- Before vs After Quality Delta Bar -->
      <div class="panel" style="margin-bottom: 24px; background: linear-gradient(90deg, #172033 0%, #1e1b4b 100%); border-color: #4338ca;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
          <div>
            <div style="font-size: 13px; color: #a5b4fc; font-weight: 700; text-transform: uppercase;">CLEANING IMPACT SCORECARD</div>
            <div style="font-size: 22px; font-weight: 800; color: #ffffff; margin-top: 2px;">
              Quality Score: <span style="color: ${cleanScore >= 80 ? '#34d399' : '#fbbf24'};">${cleanScore}%</span>
              <span style="font-size: 14px; font-weight: 600; color: #818cf8; margin-left: 8px;">
                (Baseline Raw: ${rawScore}%)
              </span>
            </div>
          </div>
          <div style="display: flex; gap: 20px;">
            <div style="text-align: right;">
              <div style="font-size: 11px; color: #94a3b8; font-weight: 700;">DUPLICATES REMOVED</div>
              <div style="font-size: 18px; font-weight: 700; color: #38bdf8;">${activeDataset.rawRows.length - activeDataset.cleanedRows.length}</div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 11px; color: #94a3b8; font-weight: 700;">TOTAL STEPS</div>
              <div style="font-size: 18px; font-weight: 700; color: #c084fc;">${activeDataset.transformationHistory.length}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Cleaning Modules Grid -->
      <div class="cleaning-grid">
        <!-- 1. Missing Values Handler -->
        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">1. Missing Value Imputation</h2>
          </div>
          <div class="panel-body">
            <label class="form-label">Select Target Column</label>
            <select id="missing-col-select" class="form-select">
              ${columns.map(c => {
                const p = profile.find(pr => pr.name === c);
                const missing = p?.missingCount || 0;
                return `<option value="${c}">${c} (${missing} missing, ${p?.inferredType})</option>`;
              }).join('')}
            </select>

            <label class="form-label" style="margin-top: 12px;">Imputation Method</label>
            <select id="missing-method-select" class="form-select">
              <option value="median">Median Imputation (Recommended for Numbers)</option>
              <option value="mean">Mean Imputation</option>
              <option value="mode">Mode Imputation (Most Frequent)</option>
              <option value="ffill">Forward Fill (Previous Valid Value)</option>
              <option value="bfill">Backward Fill (Next Valid Value)</option>
              <option value="custom">Custom Fixed Value</option>
              <option value="drop_rows">Remove Incomplete Rows</option>
              <option value="drop_col">Drop Entire Column</option>
            </select>

            <div id="missing-custom-wrap" style="display: none; margin-top: 10px;">
              <label class="form-label">Custom Replacement Value</label>
              <input type="text" id="missing-custom-val" class="form-input" placeholder="e.g. 0 or Unknown" />
            </div>

            <button id="btn-apply-missing" class="btn-primary w-full" style="margin-top: 16px;">
              Apply Missing Value Treatment
            </button>
          </div>
        </div>

        <!-- 2. Duplicate Records Remediation -->
        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">2. Deduplication Engine</h2>
          </div>
          <div class="panel-body">
            <label class="form-label">Deduplication Strategy</label>
            <select id="dedup-strategy" class="form-select">
              <option value="first">Keep First Occurrence (Standard)</option>
              <option value="last">Keep Last Occurrence</option>
              <option value="none">Remove All Instances of Duplicates</option>
            </select>

            <label class="form-label" style="margin-top: 12px;">Match Criteria</label>
            <select id="dedup-cols" class="form-select">
              <option value="all">Entire Row (All Columns Match)</option>
              ${columns.map(c => `<option value="${c}">Match only by: ${c}</option>`).join('')}
            </select>

            <p style="font-size: 12px; color: #94a3b8; margin-top: 10px;">
              Eliminating duplicate records prevents inflated revenue sums and biased analytical aggregates.
            </p>

            <button id="btn-apply-dedup" class="btn-primary w-full" style="margin-top: 16px;">
              Remove Duplicate Records
            </button>
          </div>
        </div>

        <!-- 3. Standardization & Normalization -->
        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">3. Data Standardization</h2>
          </div>
          <div class="panel-body">
            <label class="form-label">Select Standardization Operation</label>
            <select id="std-op-select" class="form-select">
              <option value="dates">Unify Date Formats to ISO (YYYY-MM-DD)</option>
              <option value="whitespace">Trim Whitespace (Leading, Trailing, Double Spaces)</option>
              <option value="categories">Normalize Categories (e.g. chennai -> Chennai)</option>
              <option value="casing_title">Convert Text to Title Case</option>
              <option value="casing_upper">Convert Text to UPPERCASE</option>
              <option value="casing_lower">Convert Text to lowercase</option>
              <option value="currency">Clean Currency Symbols ($€£,) to Numbers</option>
            </select>

            <label class="form-label" style="margin-top: 12px;">Apply to Column</label>
            <select id="std-col-select" class="form-select">
              <option value="_all">All Eligible Columns</option>
              ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
            </select>

            <button id="btn-apply-std" class="btn-primary w-full" style="margin-top: 16px;">
              Standardize Formats
            </button>
          </div>
        </div>

        <!-- 4. Outlier Detection & Treatment -->
        <div class="panel">
          <div class="panel-header">
            <h2 class="panel-title">4. Statistical Outlier Handling</h2>
          </div>
          <div class="panel-body">
            <label class="form-label">Numerical Column</label>
            <select id="outlier-col-select" class="form-select">
              ${columns.filter(c => profile.find(p => p.name === c)?.inferredType === 'number').map(c => {
                const p = profile.find(pr => pr.name === c);
                return `<option value="${c}">${c} (${p?.outlierCount || 0} outliers)</option>`;
              }).join('')}
            </select>

            <label class="form-label" style="margin-top: 12px;">Detection Method</label>
            <select id="outlier-method-select" class="form-select">
              <option value="iqr">IQR Method (Q1 - 1.5*IQR to Q3 + 1.5*IQR)</option>
              <option value="zscore">Z-Score Method (|z| > 2.5 Standard Deviations)</option>
            </select>

            <label class="form-label" style="margin-top: 12px;">Treatment Action</label>
            <select id="outlier-action-select" class="form-select">
              <option value="cap">Cap Outliers to Bounds (Winsorization - Recommended)</option>
              <option value="remove">Remove Outlier Rows Entirely</option>
            </select>

            <button id="btn-apply-outlier" class="btn-primary w-full" style="margin-top: 16px;">
              Treat Statistical Outliers
            </button>
          </div>
        </div>
      </div>

      <!-- 5. Custom Business Rules Builder -->
      <div class="panel" style="margin-top: 24px;">
        <div class="panel-header">
          <div>
            <h2 class="panel-title">5. Custom Rule Engine (IF / THEN Rules)</h2>
            <p class="panel-subtitle">Create non-code enterprise sanity rules (e.g. IF Revenue < 0 THEN drop or cap)</p>
          </div>
        </div>
        <div class="panel-body">
          <div class="rule-builder-row">
            <div class="rule-part">
              <span class="rule-label">IF COLUMN</span>
              <select id="rule-col" class="form-select">
                ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
              </select>
            </div>

            <div class="rule-part">
              <span class="rule-label">OPERATOR</span>
              <select id="rule-op" class="form-select">
                <option value="less_than">is less than (<)</option>
                <option value="greater_than">is greater than (>)</option>
                <option value="equals">equals (=)</option>
                <option value="not_equals">does not equal (!=)</option>
                <option value="is_null">is NULL / empty</option>
                <option value="contains">contains text</option>
              </select>
            </div>

            <div class="rule-part">
              <span class="rule-label">VALUE</span>
              <input type="text" id="rule-val" class="form-input" placeholder="e.g. 0" />
            </div>

            <div class="rule-part">
              <span class="rule-label">THEN ACTION</span>
              <select id="rule-action" class="form-select">
                <option value="drop_row">Drop Invalid Row</option>
                <option value="replace_median">Replace with Column Median</option>
                <option value="replace_value">Replace with Custom Value</option>
                <option value="mark_invalid">Mark as [INVALID]</option>
              </select>
            </div>

            <div class="rule-part" id="rule-target-wrap" style="display: none;">
              <span class="rule-label">TARGET REPLACEMENT</span>
              <input type="text" id="rule-target-val" class="form-input" placeholder="Replacement" />
            </div>

            <div style="display: flex; align-items: flex-end;">
              <button id="btn-apply-rule" class="btn-primary" style="height: 40px; white-space: nowrap;">
                Execute Rule
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Hook buttons & interactions
    const methodSelect = container.querySelector<HTMLSelectElement>('#missing-method-select');
    const customWrap = container.querySelector<HTMLElement>('#missing-custom-wrap');
    methodSelect?.addEventListener('change', () => {
      if (customWrap) {
        customWrap.style.display = methodSelect.value === 'custom' ? 'block' : 'none';
      }
    });

    const ruleActionSelect = container.querySelector<HTMLSelectElement>('#rule-action');
    const ruleTargetWrap = container.querySelector<HTMLElement>('#rule-target-wrap');
    ruleActionSelect?.addEventListener('change', () => {
      if (ruleTargetWrap) {
        ruleTargetWrap.style.display = ruleActionSelect.value === 'replace_value' ? 'block' : 'none';
      }
    });

    // 1-Click Auto Clean
    container.querySelector('#clean-btn-auto')?.addEventListener('click', () => {
      this.appState.run1ClickAutoClean();
    });

    // Undo
    container.querySelector('#clean-btn-undo')?.addEventListener('click', () => {
      this.appState.undo();
    });

    // Reset
    container.querySelector('#clean-btn-reset')?.addEventListener('click', () => {
      if (confirm('Revert all cleaning operations back to raw dataset state?')) {
        this.appState.resetToRaw();
      }
    });

    // Apply Missing Values
    container.querySelector('#btn-apply-missing')?.addEventListener('click', () => {
      const col = (container.querySelector('#missing-col-select') as HTMLSelectElement).value;
      const method = (container.querySelector('#missing-method-select') as HTMLSelectElement).value as any;
      const customVal = (container.querySelector('#missing-custom-val') as HTMLInputElement)?.value;

      this.appState.applyTransformation(
        `impute_${method}` as any,
        `Imputed missing values in "${col}" using ${method.toUpperCase()}`,
        (rows) => DataEngine.imputeMissing(rows, col, method, customVal),
        col,
        { method, customVal }
      );
    });

    // Apply Deduplication
    container.querySelector('#btn-apply-dedup')?.addEventListener('click', () => {
      const strategy = (container.querySelector('#dedup-strategy') as HTMLSelectElement).value as any;
      const colChoice = (container.querySelector('#dedup-cols') as HTMLSelectElement).value;
      const subset = colChoice === 'all' ? undefined : [colChoice];

      this.appState.applyTransformation(
        'remove_duplicates',
        `Removed duplicate records (Strategy: ${strategy}, ${subset ? `Key: ${colChoice}` : 'All Columns'})`,
        (rows) => DataEngine.removeDuplicates(rows, subset, strategy),
        subset ? colChoice : undefined
      );
    });

    // Apply Standardization
    container.querySelector('#btn-apply-std')?.addEventListener('click', () => {
      const op = (container.querySelector('#std-op-select') as HTMLSelectElement).value;
      const col = (container.querySelector('#std-col-select') as HTMLSelectElement).value;

      if (op === 'dates') {
        const targetCols = col === '_all' ? columns.filter(c => profile.find(p => p.name === c)?.inferredType === 'date') : [col];
        targetCols.forEach(tc => {
          this.appState.applyTransformation(
            'standardize_dates',
            `Standardized dates in "${tc}" to ISO YYYY-MM-DD`,
            (rows) => DataEngine.standardizeDates(rows, tc),
            tc
          );
        });
      } else if (op === 'whitespace') {
        const targetCols = col === '_all' ? undefined : [col];
        this.appState.applyTransformation(
          'trim_whitespace',
          `Trimmed leading/trailing and duplicate whitespace (${col === '_all' ? 'All text columns' : col})`,
          (rows) => DataEngine.trimWhitespace(rows, targetCols),
          col === '_all' ? undefined : col
        );
      } else if (op === 'categories') {
        const targetCols = col === '_all' ? columns.filter(c => profile.find(p => p.name === c)?.inferredType === 'string') : [col];
        targetCols.forEach(tc => {
          this.appState.applyTransformation(
            'normalize_categories',
            `Normalized category spelling variants in "${tc}"`,
            (rows) => DataEngine.normalizeCategories(rows, tc),
            tc
          );
        });
      } else if (op.startsWith('casing_')) {
        const casing = op.replace('casing_', '') as any;
        const targetCols = col === '_all' ? columns.filter(c => profile.find(p => p.name === c)?.inferredType === 'string') : [col];
        targetCols.forEach(tc => {
          this.appState.applyTransformation(
            'case_standardize',
            `Converted casing in "${tc}" to ${casing.toUpperCase()}`,
            (rows) => DataEngine.standardizeCasing(rows, tc, casing),
            tc,
            { casing }
          );
        });
      } else if (op === 'currency') {
        const targetCols = col === '_all' ? columns : [col];
        targetCols.forEach(tc => {
          this.appState.applyTransformation(
            'clean_currency',
            `Cleaned currency symbols and formatted numbers in "${tc}"`,
            (rows) => DataEngine.cleanCurrency(rows, tc),
            tc
          );
        });
      }
    });

    // Apply Outliers
    container.querySelector('#btn-apply-outlier')?.addEventListener('click', () => {
      const col = (container.querySelector('#outlier-col-select') as HTMLSelectElement).value;
      const method = (container.querySelector('#outlier-method-select') as HTMLSelectElement).value as any;
      const action = (container.querySelector('#outlier-action-select') as HTMLSelectElement).value as any;

      this.appState.applyTransformation(
        `handle_outliers_${method}` as any,
        `Treated outliers in "${col}" using ${method.toUpperCase()} (${action === 'cap' ? 'Winsorization cap' : 'Remove rows'})`,
        (rows) => DataEngine.handleOutliers(rows, col, method, action),
        col,
        { method, action }
      );
    });

    // Apply Custom Rule
    container.querySelector('#btn-apply-rule')?.addEventListener('click', () => {
      const col = (container.querySelector('#rule-col') as HTMLSelectElement).value;
      const operator = (container.querySelector('#rule-op') as HTMLSelectElement).value as any;
      const value = (container.querySelector('#rule-val') as HTMLInputElement).value;
      const action = (container.querySelector('#rule-action') as HTMLSelectElement).value as any;
      const targetVal = (container.querySelector('#rule-target-val') as HTMLInputElement)?.value;

      const rule: CustomRule = {
        id: `rule-${Date.now()}`,
        column: col,
        operator,
        value,
        action,
        targetValue: targetVal
      };

      this.appState.applyTransformation(
        'custom_rule',
        `Executed rule: IF [${col}] ${operator} "${value}" THEN ${action}`,
        (rows) => DataEngine.applyCustomRule(rows, rule),
        col,
        { rule }
      );
    });

    return container;
  }
}
