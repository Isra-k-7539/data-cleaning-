import { AppState } from '../appState';
import { DataEngine } from '../services/dataEngine';
import { ReportGenerator } from '../services/reportGenerator';
import { DataType } from '../types';

export class TransformationStudioView {
  private appState = AppState.getInstance();

  render(): HTMLElement {
    const container = document.createElement('div');
    container.className = 'page-container';

    const activeDataset = this.appState.getActiveDataset();
    if (!activeDataset) {
      container.innerHTML = `<div class="empty-state-card"><div class="empty-title">No dataset selected</div></div>`;
      return container;
    }

    const columns = activeDataset.columns;
    const history = activeDataset.transformationHistory;

    container.innerHTML = `
      <div class="page-header-flex">
        <div>
          <h1 class="page-title">Power Query Transformation Studio</h1>
          <p class="page-subtitle">Apply custom column calculations, row filtering, sorting, splitting, merging, and maintain a reproducible audit recipe</p>
        </div>
        <div class="page-header-actions">
          <button id="tr-btn-undo" class="btn-secondary" ${activeDataset.undoStack.length === 0 ? 'disabled' : ''}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
            Undo
          </button>
          <button id="tr-btn-redo" class="btn-secondary" ${activeDataset.redoStack.length === 0 ? 'disabled' : ''}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7"/></svg>
            Redo
          </button>
          <button id="tr-btn-export-recipe" class="btn-outline">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export Recipe JSON
          </button>
        </div>
      </div>

      <div class="transformation-layout">
        <!-- Main Transformation Workspace (Left Column) -->
        <div class="transformation-main">
          <!-- 1. Calculated Column Builder -->
          <div class="panel">
            <div class="panel-header">
              <div>
                <h2 class="panel-title">Add Calculated Column (Formula)</h2>
                <p class="panel-subtitle">Create new calculated metrics using mathematical or string operations across columns</p>
              </div>
            </div>
            <div class="panel-body">
              <div style="display: grid; grid-template-columns: 1fr 2fr auto; gap: 12px; align-items: flex-end;">
                <div>
                  <label class="form-label">New Column Name</label>
                  <input type="text" id="calc-col-name" class="form-input" placeholder="e.g. Tax_Amount or Total_Comp" />
                </div>
                <div>
                  <label class="form-label">Formula Expression (use [Column_Name])</label>
                  <input type="text" id="calc-formula" class="form-input" placeholder="e.g. [Revenue] * 0.18 or [Salary] * 1.1" />
                </div>
                <button id="btn-apply-calc" class="btn-primary" style="height: 40px;">
                  Add Column
                </button>
              </div>
              <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px;">
                <span style="font-size: 11px; color: #94a3b8; font-weight: 600;">INSERT COLUMN TOKEN:</span>
                ${columns.map(c => `<button class="token-btn" data-col="${c}">[${c}]</button>`).join('')}
              </div>
            </div>
          </div>

          <!-- 2. Row Filtering & Sorting -->
          <div class="panel" style="margin-top: 20px;">
            <div class="panel-header">
              <h2 class="panel-title">Filter & Sort Records</h2>
            </div>
            <div class="panel-body">
              <div style="display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 12px; align-items: flex-end;">
                <div>
                  <label class="form-label">Column</label>
                  <select id="filter-col" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                </div>
                <div>
                  <label class="form-label">Condition</label>
                  <select id="filter-op" class="form-select">
                    <option value="equals">Equals (=)</option>
                    <option value="not_equals">Does Not Equal (!=)</option>
                    <option value="contains">Contains Text</option>
                    <option value="greater_than">Greater Than (>)</option>
                    <option value="less_than">Less Than (<)</option>
                    <option value="is_not_null">Is Not NULL</option>
                    <option value="is_null">Is NULL</option>
                  </select>
                </div>
                <div>
                  <label class="form-label">Filter Value</label>
                  <input type="text" id="filter-val" class="form-input" placeholder="Value" />
                </div>
                <button id="btn-apply-filter" class="btn-primary" style="height: 40px;">
                  Apply Filter
                </button>
              </div>

              <!-- Sorting Row -->
              <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 12px; align-items: flex-end; margin-top: 18px; padding-top: 14px; border-top: 1px solid #334155;">
                <div>
                  <label class="form-label">Sort by Column</label>
                  <select id="sort-col" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                </div>
                <div>
                  <label class="form-label">Direction</label>
                  <select id="sort-dir" class="form-select">
                    <option value="asc">Ascending (A → Z, 0 → 9)</option>
                    <option value="desc">Descending (Z → A, 9 → 0)</option>
                  </select>
                </div>
                <button id="btn-apply-sort" class="btn-secondary" style="height: 40px;">
                  Sort Rows
                </button>
              </div>
            </div>
          </div>

          <!-- 3. Column Operations: Rename, Drop, Split, Merge, Change Type -->
          <div class="panel" style="margin-top: 20px;">
            <div class="panel-header">
              <h2 class="panel-title">Column Operations & Reshaping</h2>
            </div>
            <div class="panel-body">
              <div class="tabs-sub-row">
                <!-- Rename -->
                <div class="sub-op-card">
                  <div class="sub-op-title">Rename Column</div>
                  <select id="rename-col-old" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                  <input type="text" id="rename-col-new" class="form-input" placeholder="New Column Name" style="margin-top: 8px;" />
                  <button id="btn-apply-rename" class="btn-primary w-full" style="margin-top: 10px;">Rename</button>
                </div>

                <!-- Drop -->
                <div class="sub-op-card">
                  <div class="sub-op-title">Drop Column</div>
                  <select id="drop-col-select" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                  <p style="font-size: 11px; color: #94a3b8; margin-top: 8px;">Removes the attribute from the dataset permanently.</p>
                  <button id="btn-apply-drop" class="btn-outline w-full" style="margin-top: 10px; border-color: #ef4444; color: #f87171;">Drop</button>
                </div>

                <!-- Split -->
                <div class="sub-op-card">
                  <div class="sub-op-title">Split Column</div>
                  <select id="split-col-select" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                  <input type="text" id="split-delimiter" class="form-input" placeholder="Delimiter (e.g. space or -)" value=" " style="margin-top: 8px;" />
                  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 6px;">
                    <input type="text" id="split-part1" class="form-input" placeholder="Part 1" value="Part_1" />
                    <input type="text" id="split-part2" class="form-input" placeholder="Part 2" value="Part_2" />
                  </div>
                  <button id="btn-apply-split" class="btn-primary w-full" style="margin-top: 10px;">Split</button>
                </div>

                <!-- Change Type -->
                <div class="sub-op-card">
                  <div class="sub-op-title">Cast Data Type</div>
                  <select id="cast-col-select" class="form-select">
                    ${columns.map(c => `<option value="${c}">${c}</option>`).join('')}
                  </select>
                  <select id="cast-type-select" class="form-select" style="margin-top: 8px;">
                    <option value="number">Number</option>
                    <option value="string">Text / String</option>
                    <option value="date">Date (ISO)</option>
                    <option value="boolean">Boolean</option>
                  </select>
                  <button id="btn-apply-cast" class="btn-secondary w-full" style="margin-top: 10px;">Cast Type</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Transformation History Panel (Right Column) -->
        <div class="transformation-sidebar">
          <div class="panel h-full">
            <div class="panel-header">
              <div>
                <h2 class="panel-title">Transformation Recipe</h2>
                <p class="panel-subtitle">${history.length} steps recorded</p>
              </div>
              <button id="tr-btn-clear-history" class="btn-sm btn-outline">Clear All</button>
            </div>

            <div class="recipe-step-list">
              ${history.length === 0 ? `
                <div class="empty-state-card" style="padding: 24px;">
                  <div style="font-size: 13px; color: #94a3b8;">No transformation steps applied yet. Every operation you perform will be logged here as an audit recipe.</div>
                </div>
              ` : history.map((step, idx) => `
                <div class="recipe-step-card">
                  <div class="recipe-step-header">
                    <span class="recipe-step-num">STEP ${idx + 1}</span>
                    <span class="recipe-step-time">${step.timestamp}</span>
                  </div>
                  <div class="recipe-step-action">${step.action.replace(/_/g, ' ').toUpperCase()}</div>
                  <div class="recipe-step-desc">${step.description}</div>
                  <div class="recipe-step-meta">Impact: ${step.affectedRowsCount} row(s)</div>
                </div>
              `).join('')}
            </div>

            <div style="margin-top: 14px; padding-top: 14px; border-top: 1px solid #334155;">
              <button id="btn-recipe-copy" class="btn-outline w-full" style="font-size: 12px;">
                📋 Copy Recipe Steps as Markdown
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Formula token clicks
    container.querySelectorAll<HTMLButtonElement>('.token-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const col = btn.dataset.col;
        const formulaInput = container.querySelector<HTMLInputElement>('#calc-formula');
        if (formulaInput && col) {
          formulaInput.value += `[${col}]`;
          formulaInput.focus();
        }
      });
    });

    // Apply Calculated Column
    container.querySelector('#btn-apply-calc')?.addEventListener('click', () => {
      const colName = (container.querySelector('#calc-col-name') as HTMLInputElement).value;
      const formula = (container.querySelector('#calc-formula') as HTMLInputElement).value;
      if (!colName.trim() || !formula.trim()) {
        alert('Please enter both a column name and a formula expression.');
        return;
      }

      this.appState.applyTransformation(
        'calculated_column',
        `Added calculated column "${colName}" with formula: ${formula}`,
        (rows) => ({
          rows: DataEngine.addCalculatedColumn(rows, colName, formula),
          affected: rows.length
        }),
        colName,
        { colName, formula }
      );
    });

    // Apply Filter
    container.querySelector('#btn-apply-filter')?.addEventListener('click', () => {
      const col = (container.querySelector('#filter-col') as HTMLSelectElement).value;
      const op = (container.querySelector('#filter-op') as HTMLSelectElement).value;
      const val = (container.querySelector('#filter-val') as HTMLInputElement).value;

      this.appState.applyTransformation(
        'filter_rows',
        `Filtered rows: [${col}] ${op} "${val}"`,
        (rows) => {
          const filtered = DataEngine.filterRows(rows, col, op, val);
          return { rows: filtered, affected: rows.length - filtered.length };
        },
        col,
        { op, val }
      );
    });

    // Apply Sort
    container.querySelector('#btn-apply-sort')?.addEventListener('click', () => {
      const col = (container.querySelector('#sort-col') as HTMLSelectElement).value;
      const dir = (container.querySelector('#sort-dir') as HTMLSelectElement).value as 'asc' | 'desc';

      this.appState.applyTransformation(
        'sort_rows',
        `Sorted dataset by "${col}" (${dir.toUpperCase()})`,
        (rows) => ({
          rows: DataEngine.sortRows(rows, col, dir),
          affected: rows.length
        }),
        col,
        { dir }
      );
    });

    // Apply Rename
    container.querySelector('#btn-apply-rename')?.addEventListener('click', () => {
      const oldCol = (container.querySelector('#rename-col-old') as HTMLSelectElement).value;
      const newCol = (container.querySelector('#rename-col-new') as HTMLInputElement).value;
      if (!newCol.trim()) return;

      this.appState.applyTransformation(
        'rename_column',
        `Renamed column "${oldCol}" to "${newCol.trim()}"`,
        (rows) => ({
          rows: DataEngine.renameColumn(rows, oldCol, newCol.trim()),
          affected: rows.length
        }),
        oldCol,
        { oldCol, newCol: newCol.trim() }
      );
    });

    // Apply Drop
    container.querySelector('#btn-apply-drop')?.addEventListener('click', () => {
      const col = (container.querySelector('#drop-col-select') as HTMLSelectElement).value;
      if (confirm(`Drop column "${col}" from dataset?`)) {
        this.appState.applyTransformation(
          'drop_column',
          `Dropped column "${col}" from dataset`,
          (rows) => ({
            rows: DataEngine.dropColumn(rows, col),
            affected: rows.length
          }),
          col
        );
      }
    });

    // Apply Split
    container.querySelector('#btn-apply-split')?.addEventListener('click', () => {
      const col = (container.querySelector('#split-col-select') as HTMLSelectElement).value;
      const delim = (container.querySelector('#split-delimiter') as HTMLInputElement).value || ' ';
      const p1 = (container.querySelector('#split-part1') as HTMLInputElement).value || `${col}_1`;
      const p2 = (container.querySelector('#split-part2') as HTMLInputElement).value || `${col}_2`;

      this.appState.applyTransformation(
        'split_column',
        `Split column "${col}" by delimiter "${delim}" into "${p1}" & "${p2}"`,
        (rows) => ({
          rows: DataEngine.splitColumn(rows, col, delim, p1, p2),
          affected: rows.length
        }),
        col,
        { delim, p1, p2 }
      );
    });

    // Apply Cast
    container.querySelector('#btn-apply-cast')?.addEventListener('click', () => {
      const col = (container.querySelector('#cast-col-select') as HTMLSelectElement).value;
      const type = (container.querySelector('#cast-type-select') as HTMLSelectElement).value as DataType;

      this.appState.applyTransformation(
        'change_type',
        `Casted column "${col}" to ${type.toUpperCase()}`,
        (rows) => ({
          rows: DataEngine.changeDataType(rows, col, type),
          affected: rows.length
        }),
        col,
        { type }
      );
    });

    // Undo / Redo
    container.querySelector('#tr-btn-undo')?.addEventListener('click', () => this.appState.undo());
    container.querySelector('#tr-btn-redo')?.addEventListener('click', () => this.appState.redo());

    // Export Recipe JSON
    container.querySelector('#tr-btn-export-recipe')?.addEventListener('click', () => {
      const recipeJSON = JSON.stringify({
        datasetName: activeDataset.name,
        timestamp: new Date().toISOString(),
        steps: activeDataset.transformationHistory
      }, null, 2);
      ReportGenerator.downloadFile(recipeJSON, `${activeDataset.name.toLowerCase().replace(/\s+/g, '_')}_recipe.json`, 'application/json');
    });

    // Clear history
    container.querySelector('#tr-btn-clear-history')?.addEventListener('click', () => {
      if (confirm('Clear transformation history and reset to raw dataset?')) {
        this.appState.resetToRaw();
      }
    });

    // Copy recipe steps
    container.querySelector('#btn-recipe-copy')?.addEventListener('click', () => {
      const lines = history.map((s, idx) => `${idx + 1}. **${s.action.toUpperCase()}**: ${s.description} (${s.affectedRowsCount} rows)`).join('\n');
      navigator.clipboard.writeText(lines || 'No steps');
      alert('Recipe copied to clipboard!');
    });

    return container;
  }
}
