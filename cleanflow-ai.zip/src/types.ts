export type DataRow = Record<string, any>;

export type DataType = 'number' | 'string' | 'date' | 'boolean' | 'null';

export interface ColumnProfile {
  name: string;
  inferredType: DataType;
  totalCount: number;
  missingCount: number;
  missingPercentage: number;
  uniqueCount: number;
  sampleValues: any[];
  // Numerical stats
  min?: number;
  max?: number;
  mean?: number;
  median?: number;
  stdDev?: number;
  q1?: number;
  q3?: number;
  outlierCount?: number;
  outliers?: number[];
  // Categorical stats
  topCategories?: { value: string; count: number; percentage: number }[];
  // Inconsistencies detected
  inconsistenciesCount?: number;
  inconsistenciesExamples?: string[];
}

export interface QualityDimensions {
  completeness: number; // 0-100
  uniqueness: number;   // 0-100
  consistency: number;  // 0-100
  validity: number;     // 0-100
}

export interface QualityScore {
  overall: number; // 0-100
  dimensions: QualityDimensions;
  formula: string;
  missingPercentage: number;
  duplicatePercentage: number;
  inconsistencyPercentage: number;
}

export interface Dataset {
  id: string;
  name: string;
  source: 'upload' | 'sample';
  uploadedAt: string;
  rawRows: DataRow[];
  cleanedRows: DataRow[];
  columns: string[];
  rawProfile: ColumnProfile[];
  cleanedProfile: ColumnProfile[];
  rawQuality: QualityScore;
  cleanedQuality: QualityScore;
  transformationHistory: TransformationStep[];
  undoStack: DataRow[][];
  redoStack: DataRow[][];
  sizeBytes: number;
}

export type CleaningActionType =
  | 'impute_mean'
  | 'impute_median'
  | 'impute_mode'
  | 'impute_custom'
  | 'forward_fill'
  | 'backward_fill'
  | 'drop_missing_rows'
  | 'drop_column'
  | 'remove_duplicates'
  | 'standardize_dates'
  | 'trim_whitespace'
  | 'case_standardize'
  | 'normalize_categories'
  | 'clean_currency'
  | 'handle_outliers_iqr'
  | 'handle_outliers_zscore'
  | 'custom_rule'
  | 'rename_column'
  | 'filter_rows'
  | 'sort_rows'
  | 'split_column'
  | 'merge_columns'
  | 'change_type'
  | 'calculated_column';

export interface TransformationStep {
  id: string;
  action: CleaningActionType;
  description: string;
  column?: string;
  params?: Record<string, any>;
  timestamp: string;
  affectedRowsCount: number;
}

export interface CustomRule {
  id: string;
  column: string;
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'is_null' | 'contains';
  value: string;
  action: 'replace_value' | 'drop_row' | 'replace_median' | 'mark_invalid';
  targetValue?: string;
}

export interface PipelineTemplate {
  id: string;
  name: string;
  category: 'Sales' | 'Customer' | 'HR' | 'Finance';
  description: string;
  icon: string;
  steps: {
    action: CleaningActionType;
    column?: string;
    description: string;
    params?: Record<string, any>;
  }[];
}

export interface AutomationJob {
  id: string;
  name: string;
  datasetName: string;
  templateName: string;
  frequency: 'Daily' | 'Weekly' | 'Monthly';
  nextRun: string;
  status: 'Active' | 'Paused';
  lastRunStatus?: 'Success' | 'Failed';
  lastRunTimestamp?: string;
  recordsCleaned?: number;
}

export type ViewType =
  | 'overview'
  | 'workspace'
  | 'profiling'
  | 'cleaning'
  | 'transformation'
  | 'reports'
  | 'automation'
  | '3d_view';
