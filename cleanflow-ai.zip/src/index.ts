import { AppState } from './appState';
import { AIAssistantModal } from './components/AIAssistantModal';
import { AutomationView } from './components/AutomationView';
import { CleaningStudioView } from './components/CleaningStudioView';
import { HeaderComponent } from './components/Header';
import { OverviewView } from './components/OverviewView';
import { ProfilingView } from './components/ProfilingView';
import { ReportingView } from './components/ReportingView';
import { SidebarComponent } from './components/Sidebar';
import { ThreeDataVisualizer } from './components/ThreeDataVisualizer';
import { TransformationStudioView } from './components/TransformationStudioView';
import { WorkspaceView } from './components/WorkspaceView';

class CleanFlowApp {
  private appState = AppState.getInstance();
  private rootEl: HTMLElement;

  private headerComp = new HeaderComponent();
  private sidebarComp = new SidebarComponent();
  private overviewView = new OverviewView();
  private workspaceView = new WorkspaceView();
  private profilingView = new ProfilingView();
  private cleaningView = new CleaningStudioView();
  private transformationView = new TransformationStudioView();
  private reportingView = new ReportingView();
  private automationView = new AutomationView();
  private threeVisualizer: ThreeDataVisualizer | null = null;
  private aiAssistantModal = new AIAssistantModal();

  constructor(rootEl: HTMLElement) {
    this.rootEl = rootEl;
    this.init();
  }

  private init() {
    this.renderApp();
    this.appState.subscribe(() => {
      this.renderApp();
    });
  }

  private renderApp() {
    // If transitioning out of 3D, destroy visualizer
    if (this.appState.currentView !== '3d_view' && this.threeVisualizer) {
      this.threeVisualizer.destroy();
      this.threeVisualizer = null;
    }

    this.rootEl.innerHTML = '';

    // Render Header
    const headerNode = this.headerComp.render();
    this.rootEl.appendChild(headerNode);

    // App Body Wrapper
    const bodyWrapper = document.createElement('div');
    bodyWrapper.className = 'app-body';

    // In 3D view, sidebar can be collapsed or shown
    if (this.appState.currentView !== '3d_view') {
      const sidebarNode = this.sidebarComp.render();
      bodyWrapper.appendChild(sidebarNode);
    }

    // Main Content
    const mainContent = document.createElement('main');
    mainContent.className = 'main-content';

    switch (this.appState.currentView) {
      case 'overview':
        mainContent.appendChild(this.overviewView.render());
        break;
      case 'workspace':
        mainContent.appendChild(this.workspaceView.render());
        break;
      case 'profiling':
        mainContent.appendChild(this.profilingView.render());
        break;
      case 'cleaning':
        mainContent.appendChild(this.cleaningView.render());
        break;
      case 'transformation':
        mainContent.appendChild(this.transformationView.render());
        break;
      case 'reports':
        mainContent.appendChild(this.reportingView.render());
        break;
      case 'automation':
        mainContent.appendChild(this.automationView.render());
        break;
      case '3d_view':
        if (!this.threeVisualizer) {
          this.threeVisualizer = new ThreeDataVisualizer();
        }
        mainContent.appendChild(this.threeVisualizer.render());
        break;
      default:
        mainContent.appendChild(this.overviewView.render());
        break;
    }

    bodyWrapper.appendChild(mainContent);
    this.rootEl.appendChild(bodyWrapper);

    // AI Assistant Drawer (rendered as overlay)
    const aiDrawerNode = this.aiAssistantModal.render();
    this.rootEl.appendChild(aiDrawerNode);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('root');
  if (root) {
    new CleanFlowApp(root);
  }
});
