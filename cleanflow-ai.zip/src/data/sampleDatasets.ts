import { DataRow } from '../types';

export interface SampleDatasetDefinition {
  id: string;
  name: string;
  description: string;
  filename: string;
  category: 'Sales' | 'Customer' | 'HR' | 'Finance';
  rows: DataRow[];
}

export const SAMPLE_DATASETS: SampleDatasetDefinition[] = [
  {
    id: 'sample-sales',
    name: 'Global Sales & Revenue Logs',
    description: 'Messy transactional records with duplicate John sales, null revenues, mixed date formats (YYYY-MM-DD, DD-MM-YYYY, YYYY/MM/DD), and unstandardized cities (chennai, Chennai, CHENNAI).',
    filename: 'sales_transactions_raw.csv',
    category: 'Sales',
    rows: [
      { 'Transaction_ID': 'TXN-1001', 'Customer': 'John Doe', 'Revenue': 5000, 'Date': '2026-01-10', 'City': 'Chennai', 'Category': 'Electronics', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1001', 'Customer': 'John Doe', 'Revenue': 5000, 'Date': '2026-01-10', 'City': 'Chennai', 'Category': 'Electronics', 'Status': 'Completed' }, // Exact Duplicate
      { 'Transaction_ID': 'TXN-1002', 'Customer': 'Alice Smith', 'Revenue': null, 'Date': '2026/01/15', 'City': 'chennai', 'Category': 'Furniture', 'Status': 'Pending' },
      { 'Transaction_ID': 'TXN-1003', 'Customer': 'Bob Williams', 'Revenue': 3200, 'Date': '15-01-2026', 'City': 'Bangalore', 'Category': 'Home Goods', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1004', 'Customer': 'Diana Prince ', 'Revenue': 7800, 'Date': '2026-01-18', 'City': 'BANGALORE', 'Category': 'Electronics', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1005', 'Customer': 'Evan Wright', 'Revenue': -450, 'Date': '2026-01-20', 'City': 'Mumbai', 'Category': 'Electronics', 'Status': 'Refund' }, // Negative revenue anomaly
      { 'Transaction_ID': 'TXN-1006', 'Customer': 'Fiona Gallagher', 'Revenue': 4100, 'Date': '2026/01/22', 'City': 'mumbai ', 'Category': 'Books', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1007', 'Customer': 'George Clark', 'Revenue': null, 'Date': '25-01-2026', 'City': 'CHENNAI', 'Category': 'Electronics', 'Status': 'Pending' },
      { 'Transaction_ID': 'TXN-1008', 'Customer': 'Hannah Abbott', 'Revenue': 6200, 'Date': '2026-01-28', 'City': 'Delhi', 'Category': 'Apparel', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1009', 'Customer': 'Ian Malcolm', 'Revenue': 490000, 'Date': '2026-02-01', 'City': 'delhi', 'Category': 'Industrial', 'Status': 'Completed' }, // Extreme Outlier
      { 'Transaction_ID': 'TXN-1010', 'Customer': 'Julia Roberts', 'Revenue': 3100, 'Date': '03-02-2026', 'City': 'Chennai', 'Category': 'Apparel', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1011', 'Customer': 'Kevin Hart', 'Revenue': 2900, 'Date': '2026-02-05', 'City': 'Bangalore', 'Category': 'Books', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1012', 'Customer': 'Laura Croft', 'Revenue': 8400, 'Date': '2026/02/08', 'City': 'Mumbai', 'Category': 'Electronics', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1013', 'Customer': 'Michael Scott', 'Revenue': null, 'Date': '2026-02-12', 'City': 'Delhi', 'Category': 'Office Supplies', 'Status': 'Cancelled' },
      { 'Transaction_ID': 'TXN-1014', 'Customer': 'Nina Simone', 'Revenue': 5400, 'Date': '14-02-2026', 'City': 'chennai', 'Category': 'Music', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1015', 'Customer': 'Oscar Martinez', 'Revenue': 3900, 'Date': '2026-02-17', 'City': 'Bangalore', 'Category': 'Office Supplies', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1016', 'Customer': 'Peter Parker', 'Revenue': 7200, 'Date': '2026-02-20', 'City': 'Mumbai', 'Category': 'Apparel', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1016', 'Customer': 'Peter Parker', 'Revenue': 7200, 'Date': '2026-02-20', 'City': 'Mumbai', 'Category': 'Apparel', 'Status': 'Completed' }, // Another Duplicate
      { 'Transaction_ID': 'TXN-1017', 'Customer': 'Quinn Fabray', 'Revenue': 4500, 'Date': '2026/02/24', 'City': 'Delhi', 'Category': 'Books', 'Status': 'Completed' },
      { 'Transaction_ID': 'TXN-1018', 'Customer': 'Rachel Green', 'Revenue': 6100, 'Date': '2026-02-26', 'City': 'Chennai', 'Category': 'Apparel', 'Status': 'Completed' }
    ]
  },
  {
    id: 'sample-customer',
    name: 'Customer Demographics & CRM',
    description: 'Customer contact registry featuring negative age values, trailing whitespace in names, inconsistent phone numbers, invalid emails, and mixed casing cities.',
    filename: 'customer_crm_records.csv',
    category: 'Customer',
    rows: [
      { 'Customer_ID': 'CUST-301', 'Full_Name': 'Alexander Hamilton ', 'Email': 'alexander@corp.com', 'Age': 34, 'City': 'New York', 'Segment': 'Enterprise', 'Annual_Spend': 24000 },
      { 'Customer_ID': 'CUST-301', 'Full_Name': 'Alexander Hamilton ', 'Email': 'alexander@corp.com', 'Age': 34, 'City': 'New York', 'Segment': 'Enterprise', 'Annual_Spend': 24000 }, // Duplicate
      { 'Customer_ID': 'CUST-302', 'Full_Name': 'beatrice webb', 'Email': 'beatrice_at_domain', 'Age': 29, 'City': 'new york', 'Segment': 'SMB', 'Annual_Spend': 5400 }, // Invalid email, lowercase name
      { 'Customer_ID': 'CUST-303', 'Full_Name': 'Charles Darwin', 'Email': 'charles.darwin@nature.org', 'Age': -5, 'City': 'London', 'Segment': 'Consumer', 'Annual_Spend': 1200 }, // Negative age anomaly
      { 'Customer_ID': 'CUST-304', 'Full_Name': 'David Copperfield', 'Email': null, 'Age': 41, 'City': 'London ', 'Segment': 'Enterprise', 'Annual_Spend': 45000 },
      { 'Customer_ID': 'CUST-305', 'Full_Name': 'Eleanor Roosevelt', 'Email': 'eleanor@whitehouse.gov', 'Age': 58, 'City': 'LONDON', 'Segment': 'Enterprise', 'Annual_Spend': 38000 },
      { 'Customer_ID': 'CUST-306', 'Full_Name': 'Franklin Chang', 'Email': 'franklin@space.tech', 'Age': null, 'City': 'San Francisco', 'Segment': 'SMB', 'Annual_Spend': 9200 },
      { 'Customer_ID': 'CUST-307', 'Full_Name': 'Grace Hopper', 'Email': 'grace.hopper@navy.mil', 'Age': 72, 'City': 'san francisco', 'Segment': 'Enterprise', 'Annual_Spend': 67000 },
      { 'Customer_ID': 'CUST-308', 'Full_Name': 'Hedy Lamarr', 'Email': 'hedy@patents.com', 'Age': 33, 'City': 'San Francisco', 'Segment': 'Consumer', 'Annual_Spend': 3100 },
      { 'Customer_ID': 'CUST-309', 'Full_Name': 'Isaac Newton', 'Email': 'isaac@gravity.edu', 'Age': 195, 'City': 'Cambridge', 'Segment': 'SMB', 'Annual_Spend': 15000 }, // Age outlier
      { 'Customer_ID': 'CUST-310', 'Full_Name': 'Joan of Arc', 'Email': 'joan@orleans.fr', 'Age': 28, 'City': 'Paris', 'Segment': 'Consumer', 'Annual_Spend': null },
      { 'Customer_ID': 'CUST-311', 'Full_Name': 'Katherine Johnson', 'Email': 'katherine@nasa.gov', 'Age': 45, 'City': 'paris', 'Segment': 'Enterprise', 'Annual_Spend': 51000 },
      { 'Customer_ID': 'CUST-312', 'Full_Name': 'Leonardo DaVinci', 'Email': 'leo@florence.art', 'Age': 52, 'City': 'PARIS', 'Segment': 'Enterprise', 'Annual_Spend': 89000 },
      { 'Customer_ID': 'CUST-313', 'Full_Name': 'Marie Curie', 'Email': 'marie@radium.org', 'Age': 39, 'City': 'Paris', 'Segment': 'SMB', 'Annual_Spend': 18000 },
      { 'Customer_ID': 'CUST-314', 'Full_Name': 'Nikola Tesla', 'Email': 'nikola@alternating.com', 'Age': 36, 'City': 'New York', 'Segment': 'Consumer', 'Annual_Spend': 4200 }
    ]
  },
  {
    id: 'sample-employee',
    name: 'Employee HR & Payroll Audit',
    description: 'Human resources records with inconsistent department names (ENG, Engineering, engineering), salary typos ($99,999,999), unformatted hire dates, and missing bonus values.',
    filename: 'employee_payroll_records.csv',
    category: 'HR',
    rows: [
      { 'Emp_ID': 'EMP-701', 'Employee_Name': 'Arthur Dent', 'Department': 'Engineering', 'Salary': 95000, 'Hire_Date': '2023-04-12', 'Bonus_Pct': 10, 'Location': 'Remote' },
      { 'Emp_ID': 'EMP-702', 'Employee_Name': 'Ford Prefect', 'Department': 'engineering', 'Salary': 98000, 'Hire_Date': '12/04/2023', 'Bonus_Pct': 12, 'Location': 'Remote' },
      { 'Emp_ID': 'EMP-703', 'Employee_Name': 'Tricia McMillan', 'Department': 'ENG', 'Salary': 115000, 'Hire_Date': '2022-09-01', 'Bonus_Pct': 15, 'Location': 'HQ' },
      { 'Emp_ID': 'EMP-704', 'Employee_Name': 'Zaphod Beeblebrox', 'Department': 'Marketing', 'Salary': 99999999, 'Hire_Date': '2021-01-15', 'Bonus_Pct': null, 'Location': 'HQ' }, // Extreme salary typo
      { 'Emp_ID': 'EMP-705', 'Employee_Name': 'Marvin Paranoid', 'Department': 'IT Support', 'Salary': 72000, 'Hire_Date': '2024-03-10', 'Bonus_Pct': 5, 'Location': 'Remote' },
      { 'Emp_ID': 'EMP-705', 'Employee_Name': 'Marvin Paranoid', 'Department': 'IT Support', 'Salary': 72000, 'Hire_Date': '2024-03-10', 'Bonus_Pct': 5, 'Location': 'Remote' }, // Duplicate
      { 'Emp_ID': 'EMP-706', 'Employee_Name': 'Slartibartfast ', 'Department': 'Engineering', 'Salary': 125000, 'Hire_Date': '2020-07-22', 'Bonus_Pct': 20, 'Location': 'HQ' },
      { 'Emp_ID': 'EMP-707', 'Employee_Name': 'Agrajag G', 'Department': null, 'Salary': 68000, 'Hire_Date': '2024-06-01', 'Bonus_Pct': 5, 'Location': 'HQ' }, // Missing dept
      { 'Emp_ID': 'EMP-708', 'Employee_Name': 'Eddie Computer', 'Department': 'IT Support', 'Salary': null, 'Hire_Date': '2023-11-18', 'Bonus_Pct': 8, 'Location': 'Remote' }, // Missing salary
      { 'Emp_ID': 'EMP-709', 'Employee_Name': 'Gellu Meka', 'Department': 'marketing', 'Salary': 82000, 'Hire_Date': '18-11-2023', 'Bonus_Pct': 10, 'Location': 'HQ' },
      { 'Emp_ID': 'EMP-710', 'Employee_Name': 'Deep Thought', 'Department': 'Engineering', 'Salary': 140000, 'Hire_Date': '2019-02-14', 'Bonus_Pct': 25, 'Location': 'HQ' },
      { 'Emp_ID': 'EMP-711', 'Employee_Name': 'Benjy Mouse', 'Department': 'Finance', 'Salary': 88000, 'Hire_Date': '2022-05-30', 'Bonus_Pct': null, 'Location': 'HQ' },
      { 'Emp_ID': 'EMP-712', 'Employee_Name': 'Frankie Mouse', 'Department': 'FINANCE', 'Salary': 89000, 'Hire_Date': '2022-06-15', 'Bonus_Pct': 12, 'Location': 'HQ' }
    ]
  },
  {
    id: 'sample-finance',
    name: 'Financial Ledger & Expenses',
    description: 'Corporate ledger showing currency symbols inside numbers, duplicate invoice codes, missing cost centers, and non-standard accounting dates.',
    filename: 'corporate_ledger_q1.csv',
    category: 'Finance',
    rows: [
      { 'Invoice_Num': 'INV-9001', 'Vendor': 'Amazon Web Services', 'Amount': 4200.50, 'Tax': 756.09, 'Cost_Center': 'Engineering', 'Date': '2026-01-05' },
      { 'Invoice_Num': 'INV-9001', 'Vendor': 'Amazon Web Services', 'Amount': 4200.50, 'Tax': 756.09, 'Cost_Center': 'Engineering', 'Date': '2026-01-05' }, // Duplicate
      { 'Invoice_Num': 'INV-9002', 'Vendor': 'Google Cloud Platform', 'Amount': 6150.00, 'Tax': null, 'Cost_Center': 'Engineering', 'Date': '2026/01/12' },
      { 'Invoice_Num': 'INV-9003', 'Vendor': 'Slack Technologies', 'Amount': 1800.00, 'Tax': 324.00, 'Cost_Center': 'it', 'Date': '12-01-2026' },
      { 'Invoice_Num': 'INV-9004', 'Vendor': 'Figma Inc.', 'Amount': 2400.00, 'Tax': 432.00, 'Cost_Center': 'Design', 'Date': '2026-01-18' },
      { 'Invoice_Num': 'INV-9005', 'Vendor': 'Datadog APM', 'Amount': null, 'Tax': 540.00, 'Cost_Center': 'Engineering', 'Date': '2026-01-22' },
      { 'Invoice_Num': 'INV-9006', 'Vendor': 'WeWork Offices', 'Amount': 15000.00, 'Tax': 2700.00, 'Cost_Center': 'Operations', 'Date': '2026-01-30' },
      { 'Invoice_Num': 'INV-9007', 'Vendor': 'HubSpot CRM', 'Amount': 3400.00, 'Tax': 612.00, 'Cost_Center': 'MARKETING', 'Date': '2026/02/04' },
      { 'Invoice_Num': 'INV-9008', 'Vendor': 'Stripe Fees', 'Amount': 890.20, 'Tax': 160.23, 'Cost_Center': 'finance', 'Date': '2026-02-10' },
      { 'Invoice_Num': 'INV-9009', 'Vendor': 'Zoom Video', 'Amount': 950.00, 'Tax': null, 'Cost_Center': 'IT', 'Date': '15-02-2026' },
      { 'Invoice_Num': 'INV-9010', 'Vendor': 'OpenAI API', 'Amount': 185000.00, 'Tax': 33300.00, 'Cost_Center': 'Engineering', 'Date': '2026-02-20' } // Spike/Outlier
    ]
  }
];
