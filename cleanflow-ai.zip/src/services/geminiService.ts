import { ColumnProfile, DataRow, QualityScore } from '../types';

export interface AIResponse {
  answer: string;
  recommendedActions?: {
    action: string;
    column?: string;
    method?: string;
    description: string;
  }[];
}

export class GeminiAssistantService {
  /**
   * Ask the AI Assistant for recommendations, diagnostics, or natural-language cleaning commands.
   */
  static async queryAssistant(
    prompt: string,
    context: {
      datasetName: string;
      columns: string[];
      profile: ColumnProfile[];
      quality: QualityScore;
      rowsSample: DataRow[];
    }
  ): Promise<AIResponse> {
    const promptLower = prompt.toLowerCase();

    // Natural Language Command Parser (Deterministic & Instant)
    const detectedActions: { action: string; column?: string; method?: string; description: string }[] = [];

    if (promptLower.includes('duplicate') || promptLower.includes('dedup')) {
      detectedActions.push({
        action: 'remove_duplicates',
        description: 'Remove all duplicate records from the dataset'
      });
    }

    if (promptLower.includes('whitespace') || promptLower.includes('trim') || promptLower.includes('spaces')) {
      detectedActions.push({
        action: 'trim_whitespace',
        description: 'Trim leading/trailing and redundant whitespace across all text columns'
      });
    }

    if (promptLower.includes('date') || promptLower.includes('standardize date')) {
      const dateCol = context.columns.find(c => c.toLowerCase().includes('date') || c.toLowerCase().includes('hire') || c.toLowerCase().includes('time'));
      if (dateCol) {
        detectedActions.push({
          action: 'standardize_dates',
          column: dateCol,
          description: `Standardize date formats in column "${dateCol}" to YYYY-MM-DD`
        });
      }
    }

    if (promptLower.includes('missing') || promptLower.includes('null') || promptLower.includes('fill') || promptLower.includes('impute')) {
      let method = 'median';
      if (promptLower.includes('mean')) method = 'mean';
      else if (promptLower.includes('mode')) method = 'mode';

      // Find target column or all numerical
      let targetCol = context.columns.find(c => promptLower.includes(c.toLowerCase()));
      if (targetCol) {
        detectedActions.push({
          action: `impute_${method}`,
          column: targetCol,
          method,
          description: `Impute missing values in "${targetCol}" using ${method.toUpperCase()}`
        });
      } else {
        // Find columns with missing values
        context.profile.forEach(p => {
          if (p.missingCount > 0) {
            const m = p.inferredType === 'number' ? 'median' : 'mode';
            detectedActions.push({
              action: `impute_${m}`,
              column: p.name,
              method: m,
              description: `Impute missing values in "${p.name}" (${p.missingCount} empty) using ${m.toUpperCase()}`
            });
          }
        });
      }
    }

    if (promptLower.includes('outlier') || promptLower.includes('cap')) {
      const numCol = context.columns.find(c => {
        const prof = context.profile.find(p => p.name === c);
        return prof && prof.outlierCount && prof.outlierCount > 0;
      });
      if (numCol) {
        detectedActions.push({
          action: 'handle_outliers_iqr',
          column: numCol,
          description: `Cap statistical outliers in "${numCol}" to IQR bounds (Winsorization)`
        });
      }
    }

    if (promptLower.includes('city') || promptLower.includes('location') || promptLower.includes('category') || promptLower.includes('casing')) {
      const textCol = context.columns.find(c => c.toLowerCase().includes('city') || c.toLowerCase().includes('dept') || c.toLowerCase().includes('category'));
      if (textCol) {
        detectedActions.push({
          action: 'normalize_categories',
          column: textCol,
          description: `Normalize categories and text casing in "${textCol}"`
        });
      }
    }

    // Try server API call if available, or fall back to high-grade rule-based responses
    try {
      const res = await fetch('/api/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, context })
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.answer) {
          return {
            answer: data.answer,
            recommendedActions: data.recommendedActions || detectedActions
          };
        }
      }
    } catch {
      // Graceful fallback to built-in analytics diagnostic
    }

    // Comprehensive heuristic expert response
    let answerText = '';

    if (promptLower.includes('why') && (promptLower.includes('score') || promptLower.includes('quality') || promptLower.includes('low'))) {
      answerText = `### Data Quality Assessment for **${context.datasetName}**\n\n` +
        `The current dataset quality score is **${context.quality.overall}%**. Here is the breakdown:\n\n` +
        `1. **Missing Data (${context.quality.missingPercentage}%)**: Empty cells detected in columns (${context.profile.filter(p => p.missingCount > 0).map(p => `\`${p.name}\` (${p.missingCount} missing)`).join(', ') || 'None'}).\n` +
        `2. **Duplicate Records (${context.quality.duplicatePercentage}%)**: Duplicate rows reduce uniqueness and skew aggregates.\n` +
        `3. **Inconsistencies (${context.quality.inconsistencyPercentage}%)**: Mixed date formatting, casing discrepancies (e.g. uppercase vs lowercase), and statistical outliers.\n\n` +
        `**Recommended Actions:**\n` +
        `- Apply **Deduplication** to eliminate redundant records.\n` +
        `- Impute missing values with **Median** (for numbers) or **Mode** (for text).\n` +
        `- Run **Date Standardization** to unify dates to ISO \`YYYY-MM-DD\`.\n` +
        `- Standardize text casings and trim whitespace.`;
    } else if (detectedActions.length > 0) {
      answerText = `I analyzed your request: _"${prompt}"_.\n\n` +
        `I generated **${detectedActions.length} automated cleaning step(s)** for dataset **${context.datasetName}**:\n` +
        detectedActions.map((a, i) => `${i + 1}. **${a.description}**`).join('\n') +
        `\n\nClick **"Apply Generated Cleaning Plan"** below to execute these operations with live before/after previews.`;
    } else {
      answerText = `### CleanFlow AI Assistant Insights\n\n` +
        `For **${context.datasetName}**, I recommend the following priority operations:\n\n` +
        `• **Remove Duplicates**: Eliminate repeated rows to protect model training and financial aggregates.\n` +
        `• **Impute Missing Values**: Fill gaps without distorting distribution variances using Median or Mode.\n` +
        `• **Standardize Text & Dates**: Eliminate trailing spaces and unify date separators.\n\n` +
        `You can instruct me in natural language, for example:\n` +
        `• _"Remove all duplicate rows and fill missing values with median"_\n` +
        `• _"Standardize date formats and trim whitespace"_\n` +
        `• _"Why does my dataset have a low quality score?"_`;
    }

    return {
      answer: answerText,
      recommendedActions: detectedActions
    };
  }
}
