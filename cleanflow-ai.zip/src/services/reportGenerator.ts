import { Dataset } from '../types';

export class ReportGenerator {
  /**
   * Generates a rich, printable HTML executive data quality report.
   */
  static generateExecutiveHTMLReport(dataset: Dataset): string {
    const rawCount = dataset.rawRows.length;
    const cleanCount = dataset.cleanedRows.length;
    const rawScore = dataset.rawQuality.overall;
    const cleanScore = dataset.cleanedQuality.overall;
    const scoreDiff = cleanScore - rawScore;

    const rawMissing = dataset.rawProfile.reduce((acc, p) => acc + p.missingCount, 0);
    const cleanMissing = dataset.cleanedProfile.reduce((acc, p) => acc + p.missingCount, 0);

    const historyItems = dataset.transformationHistory.length > 0
      ? dataset.transformationHistory.map((s, idx) => `
          <tr>
            <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; font-family: monospace; color: #a0aec0;">#${idx + 1}</td>
            <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; font-weight: 600; color: #e2e8f0;">${s.action.replace(/_/g, ' ').toUpperCase()}</td>
            <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #cbd5e0;">${s.description}</td>
            <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #63b3ed;">${s.affectedRowsCount} rows</td>
            <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #a0aec0;">${s.timestamp}</td>
          </tr>
        `).join('')
      : `<tr><td colspan="5" style="padding: 16px; text-align: center; color: #718096;">No cleaning transformations applied yet. Dataset remains in raw state.</td></tr>`;

    const columnStatsRows = dataset.cleanedProfile.map(col => `
      <tr>
        <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; font-weight: 600; color: #f7fafc;">${col.name}</td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #81e6d9; text-transform: uppercase; font-size: 12px; font-weight: 700;">${col.inferredType}</td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #e2e8f0;">${col.uniqueCount}</td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: ${col.missingCount > 0 ? '#fc8181' : '#68d391'}; font-weight: 600;">${col.missingCount} (${col.missingPercentage}%)</td>
        <td style="padding: 10px 14px; border-bottom: 1px solid #2d3748; color: #cbd5e0;">${col.mean !== undefined ? `Mean: ${col.mean} | Med: ${col.median}` : (col.topCategories?.[0]?.value ? `Top: "${col.topCategories[0].value}"` : 'N/A')}</td>
      </tr>
    `).join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CleanFlow AI - Executive Audit Report: ${dataset.name}</title>
  <style>
    @media print {
      body { background: #ffffff !important; color: #1a202c !important; }
      .no-print { display: none !important; }
      .page-break { page-break-after: always; }
      .card { border: 1px solid #e2e8f0 !important; background: #ffffff !important; color: #1a202c !important; }
      th { background: #edf2f7 !important; color: #2d3748 !important; }
      td { color: #2d3748 !important; border-bottom: 1px solid #e2e8f0 !important; }
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: #0b0f19;
      color: #f8fafc;
      margin: 0;
      padding: 32px 24px;
      line-height: 1.6;
    }
    .container {
      max-width: 1000px;
      margin: 0 auto;
    }
    .header {
      border-bottom: 2px solid #2d3748;
      padding-bottom: 20px;
      margin-bottom: 28px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .title {
      font-size: 28px;
      font-weight: 800;
      color: #ffffff;
      margin: 0 0 6px 0;
      letter-spacing: -0.5px;
    }
    .subtitle {
      color: #94a3b8;
      font-size: 14px;
      margin: 0;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 28px;
    }
    .card {
      background: #172033;
      border: 1px solid #2d3748;
      border-radius: 12px;
      padding: 18px;
    }
    .card-label {
      font-size: 12px;
      font-weight: 700;
      color: #94a3b8;
      text-transform: uppercase;
      margin-bottom: 8px;
      letter-spacing: 0.5px;
    }
    .card-val {
      font-size: 26px;
      font-weight: 800;
      color: #f8fafc;
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      margin-top: 6px;
    }
    .badge-success { background: rgba(16, 185, 129, 0.2); color: #34d399; }
    .badge-info { background: rgba(99, 102, 241, 0.2); color: #818cf8; }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 13px;
    }
    th {
      background: #1e293b;
      color: #94a3b8;
      text-transform: uppercase;
      font-size: 11px;
      font-weight: 700;
      padding: 12px 14px;
      border-bottom: 2px solid #334155;
    }
    .section-title {
      font-size: 18px;
      font-weight: 700;
      color: #e2e8f0;
      margin: 28px 0 14px 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .btn-print {
      background: #6366f1;
      color: #ffffff;
      border: none;
      padding: 10px 18px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div>
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
          <span style="background: #6366f1; color: white; padding: 4px 10px; border-radius: 6px; font-weight: 800; font-size: 12px; letter-spacing: 1px;">CLEANFLOW AI</span>
          <span style="color: #64748b; font-size: 13px;">Enterprise Data Quality Audit</span>
        </div>
        <h1 class="title">${dataset.name}</h1>
        <p class="subtitle">Generated automatically on ${new Date().toLocaleString()} | Source: ${dataset.source.toUpperCase()}</p>
      </div>
      <div class="no-print">
        <button class="btn-print" onclick="window.print()">Print / Export PDF</button>
      </div>
    </div>

    <!-- Top KPI Grid -->
    <div class="grid">
      <div class="card">
        <div class="card-label">Overall Quality Score</div>
        <div class="card-val" style="color: ${cleanScore >= 80 ? '#34d399' : cleanScore >= 60 ? '#fbbf24' : '#f87171'};">${cleanScore}%</div>
        <span class="badge ${scoreDiff >= 0 ? 'badge-success' : 'badge-info'}">
          ${scoreDiff >= 0 ? `+${scoreDiff}% vs Raw` : `${scoreDiff}%`}
        </span>
      </div>

      <div class="card">
        <div class="card-label">Total Clean Records</div>
        <div class="card-val">${cleanCount}</div>
        <div style="font-size: 12px; color: #94a3b8; margin-top: 6px;">Original: ${rawCount} rows</div>
      </div>

      <div class="card">
        <div class="card-label">Missing Values Handled</div>
        <div class="card-val" style="color: #818cf8;">${Math.max(0, rawMissing - cleanMissing)}</div>
        <div style="font-size: 12px; color: #94a3b8; margin-top: 6px;">Remaining: ${cleanMissing} cells</div>
      </div>

      <div class="card">
        <div class="card-label">Duplicates Removed</div>
        <div class="card-val" style="color: #38bdf8;">${rawCount - cleanCount}</div>
        <div style="font-size: 12px; color: #94a3b8; margin-top: 6px;">Deduplication Rate: ${(((rawCount - cleanCount) / Math.max(1, rawCount)) * 100).toFixed(1)}%</div>
      </div>
    </div>

    <!-- Executive Summary -->
    <div class="card" style="margin-bottom: 24px; border-left: 4px solid #6366f1;">
      <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #f8fafc;">Executive Summary</h3>
      <p style="margin: 0; font-size: 14px; color: #cbd5e0; line-height: 1.7;">
        The dataset <strong>"${dataset.name}"</strong> has undergone automated data profiling, anomaly detection, and comprehensive cleaning using CleanFlow AI's deterministic processing engine. 
        The overall Data Quality Index improved from <strong>${rawScore}%</strong> to <strong>${cleanScore}%</strong>. 
        All detected record redundancies, missing attributes, inconsistent date formats, and casing variations were systematically addressed according to enterprise preparation rules. The dataset is now verified and ready for reliable business reporting and downstream BI ingestion.
      </p>
    </div>

    <!-- Quality Dimensions Breakdown -->
    <div class="section-title">Data Quality Dimension Scorecard</div>
    <div class="card" style="margin-bottom: 28px;">
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; text-align: center;">
        <div>
          <div style="font-size: 12px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Completeness</div>
          <div style="font-size: 24px; font-weight: 800; color: #34d399; margin-top: 4px;">${dataset.cleanedQuality.dimensions.completeness}%</div>
        </div>
        <div>
          <div style="font-size: 12px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Uniqueness</div>
          <div style="font-size: 24px; font-weight: 800; color: #38bdf8; margin-top: 4px;">${dataset.cleanedQuality.dimensions.uniqueness}%</div>
        </div>
        <div>
          <div style="font-size: 12px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Consistency</div>
          <div style="font-size: 24px; font-weight: 800; color: #818cf8; margin-top: 4px;">${dataset.cleanedQuality.dimensions.consistency}%</div>
        </div>
        <div>
          <div style="font-size: 12px; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Validity</div>
          <div style="font-size: 24px; font-weight: 800; color: #a78bfa; margin-top: 4px;">${dataset.cleanedQuality.dimensions.validity}%</div>
        </div>
      </div>
      <div style="margin-top: 14px; font-size: 11px; color: #94a3b8; text-align: center; border-top: 1px solid #334155; padding-top: 10px;">
        Scoring Formula: <code>Quality Score = 100 - (0.40 * Missing% + 0.35 * Duplicate% + 0.25 * Inconsistency%)</code>
      </div>
    </div>

    <!-- Transformation Operations Log -->
    <div class="section-title">Cleaning & Transformation Audit Trail (${dataset.transformationHistory.length} Steps)</div>
    <div class="card" style="padding: 0; overflow: hidden; margin-bottom: 28px;">
      <table>
        <thead>
          <tr>
            <th>Step</th>
            <th>Operation</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          ${historyItems}
        </tbody>
      </table>
    </div>

    <!-- Column Profile Summary -->
    <div class="section-title">Cleaned Column Schema & Statistics (${dataset.columns.length} Attributes)</div>
    <div class="card" style="padding: 0; overflow: hidden;">
      <table>
        <thead>
          <tr>
            <th>Column Name</th>
            <th>Data Type</th>
            <th>Unique Values</th>
            <th>Missing Rate</th>
            <th>Key Metric / Distribution</th>
          </tr>
        </thead>
        <tbody>
          ${columnStatsRows}
        </tbody>
      </table>
    </div>

    <div style="margin-top: 32px; padding-top: 18px; border-top: 1px solid #334155; text-align: center; color: #64748b; font-size: 12px;">
      Report compiled by CleanFlow AI Enterprise Data Engine • Confidential & Proprietary
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * Export dataset rows as standard CSV string.
   */
  static exportToCSV(dataset: Dataset): string {
    const columns = dataset.columns;
    const headerLine = columns.map(c => `"${c.replace(/"/g, '""')}"`).join(',');
    const rowsLines = dataset.cleanedRows.map(r => {
      return columns.map(c => {
        const val = r[c];
        if (val === null || val === undefined) return '';
        const str = String(val);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(',');
    });
    return [headerLine, ...rowsLines].join('\n');
  }

  /**
   * Export dataset rows as formatted JSON.
   */
  static exportToJSON(dataset: Dataset): string {
    return JSON.stringify(dataset.cleanedRows, null, 2);
  }

  /**
   * Triggers a browser download of text/blob.
   */
  static downloadFile(content: string, filename: string, mimeType: string): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
