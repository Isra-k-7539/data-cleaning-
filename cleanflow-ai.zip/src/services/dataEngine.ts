import {
  ColumnProfile,
  CustomRule,
  DataRow,
  DataType,
  QualityDimensions,
  QualityScore,
  TransformationStep
} from '../types';

export class DataEngine {
  /**
   * Parse CSV text with full RFC-4180 quote support.
   */
  static parseCSV(csvText: string): { columns: string[]; rows: DataRow[] } {
    const lines: string[] = [];
    let currentLine = '';
    let inQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i + 1];

      if (char === '"' || char === "'") {
        if (inQuotes && (nextChar === '"' || nextChar === "'")) {
          currentLine += char;
          i++; // Skip escaped quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if ((char === '\r' || char === '\n') && !inQuotes) {
        if (char === '\r' && nextChar === '\n') i++;
        if (currentLine.trim()) lines.push(currentLine);
        currentLine = '';
      } else {
        currentLine += char;
      }
    }
    if (currentLine.trim()) lines.push(currentLine);

    if (lines.length === 0) return { columns: [], rows: [] };

    const splitRow = (rowStr: string): string[] => {
      const items: string[] = [];
      let item = '';
      let quotes = false;
      for (let i = 0; i < rowStr.length; i++) {
        const c = rowStr[i];
        if (c === '"' || c === "'") {
          quotes = !quotes;
        } else if (c === ',' && !quotes) {
          items.push(item.trim());
          item = '';
        } else {
          item += c;
        }
      }
      items.push(item.trim());
      return items.map(s => s.replace(/^["']|["']$/g, '').trim());
    };

    const header = splitRow(lines[0]);
    const rows: DataRow[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = splitRow(lines[i]);
      if (values.every(v => v === '')) continue;
      const row: DataRow = {};
      header.forEach((col, idx) => {
        const rawVal = values[idx] ?? '';
        row[col] = this.inferValueType(rawVal);
      });
      rows.push(row);
    }

    return { columns: header, rows };
  }

  /**
   * Parse JSON string (array of objects).
   */
  static parseJSON(jsonText: string): { columns: string[]; rows: DataRow[] } {
    try {
      const parsed = JSON.parse(jsonText);
      const rowsArray = Array.isArray(parsed) ? parsed : [parsed];
      if (rowsArray.length === 0) return { columns: [], rows: [] };

      const colSet = new Set<string>();
      rowsArray.forEach(r => {
        if (typeof r === 'object' && r !== null) {
          Object.keys(r).forEach(k => colSet.add(k));
        }
      });
      const columns = Array.from(colSet);
      const rows = rowsArray.map(r => {
        const row: DataRow = {};
        columns.forEach(c => {
          row[c] = r[c] ?? null;
        });
        return row;
      });
      return { columns, rows };
    } catch {
      throw new Error('Invalid JSON format. Please provide an array of JSON objects.');
    }
  }

  /**
   * Convert typed string values to numbers, dates, booleans, or nulls.
   */
  static inferValueType(val: string): any {
    if (val === '' || val === null || val === undefined) return null;
    const lower = val.toLowerCase().trim();
    if (lower === 'null' || lower === 'none' || lower === 'nan' || lower === 'n/a') return null;
    if (lower === 'true') return true;
    if (lower === 'false') return false;

    // Numerical check (handles currency $ or commas like $1,250.50)
    const cleanNumStr = val.replace(/[$€£,]/g, '').trim();
    if (!isNaN(Number(cleanNumStr)) && cleanNumStr !== '') {
      return Number(cleanNumStr);
    }

    return val;
  }

  /**
   * Inferred data type of a column based on all rows.
   */
  static detectColumnType(values: any[]): DataType {
    const nonNulls = values.filter(v => v !== null && v !== undefined && v !== '');
    if (nonNulls.length === 0) return 'null';

    let numCount = 0;
    let dateCount = 0;
    let boolCount = 0;

    for (const v of nonNulls) {
      if (typeof v === 'boolean') boolCount++;
      else if (typeof v === 'number') numCount++;
      else if (this.isDateString(String(v))) dateCount++;
      else if (!isNaN(Number(String(v).replace(/[$€£,]/g, '')))) numCount++;
    }

    const total = nonNulls.length;
    if (boolCount / total > 0.7) return 'boolean';
    if (numCount / total > 0.7) return 'number';
    if (dateCount / total > 0.6) return 'date';
    return 'string';
  }

  static isDateString(str: string): boolean {
    if (!str || typeof str !== 'string' || str.length < 6) return false;
    // matches YYYY-MM-DD, YYYY/MM/DD, DD-MM-YYYY, DD/MM/YYYY
    const datePattern = /^(\d{4}[-/]\d{1,2}[-/]\d{1,2})|(\d{1,2}[-/]\d{1,2}[-/]\d{4})$/;
    if (datePattern.test(str.trim())) return true;
    const timestamp = Date.parse(str);
    return !isNaN(timestamp) && !/^\d+$/.test(str.trim());
  }

  /**
   * Comprehensive Dataset Profiling & Health Scoring.
   */
  static profileDataset(rows: DataRow[], columns: string[]): { profile: ColumnProfile[]; quality: QualityScore } {
    if (rows.length === 0 || columns.length === 0) {
      return {
        profile: [],
        quality: {
          overall: 100,
          dimensions: { completeness: 100, uniqueness: 100, consistency: 100, validity: 100 },
          formula: 'Quality Score = 100 - (0.40 * M + 0.35 * D + 0.25 * I)',
          missingPercentage: 0,
          duplicatePercentage: 0,
          inconsistencyPercentage: 0
        }
      };
    }

    const totalRows = rows.length;
    let totalCells = totalRows * columns.length;
    let totalMissingCells = 0;
    let totalInconsistencies = 0;

    // Check Duplicate Rows
    const rowHashes = new Set<string>();
    let duplicateRowsCount = 0;
    rows.forEach(r => {
      const hash = JSON.stringify(r);
      if (rowHashes.has(hash)) duplicateRowsCount++;
      else rowHashes.add(hash);
    });
    const duplicatePercentage = (duplicateRowsCount / totalRows) * 100;

    const profile: ColumnProfile[] = columns.map(col => {
      const values = rows.map(r => r[col]);
      const missingCount = values.filter(v => v === null || v === undefined || v === '' || v === 'NULL' || v === 'null').length;
      totalMissingCells += missingCount;

      const nonNulls = values.filter(v => v !== null && v !== undefined && v !== '' && v !== 'NULL' && v !== 'null');
      const inferredType = this.detectColumnType(values);

      const uniqueSet = new Set(nonNulls.map(v => typeof v === 'object' ? JSON.stringify(v) : String(v)));
      const uniqueCount = uniqueSet.size;

      const colProf: ColumnProfile = {
        name: col,
        inferredType,
        totalCount: totalRows,
        missingCount,
        missingPercentage: Number(((missingCount / totalRows) * 100).toFixed(1)),
        uniqueCount,
        sampleValues: nonNulls.slice(0, 5),
        inconsistenciesCount: 0,
        inconsistenciesExamples: []
      };

      // Inconsistency checks:
      if (inferredType === 'date') {
        const dateFormats = new Set<string>();
        nonNulls.forEach(val => {
          const s = String(val).trim();
          if (s.includes('/')) dateFormats.add('slash');
          if (s.includes('-')) dateFormats.add('dash');
          if (/^\d{2}-/.test(s)) dateFormats.add('dd-first');
          if (/^\d{4}-/.test(s)) dateFormats.add('yyyy-first');
        });
        if (dateFormats.size > 1) {
          colProf.inconsistenciesCount = (colProf.inconsistenciesCount || 0) + 1;
          colProf.inconsistenciesExamples?.push('Mixed date formats (e.g. YYYY-MM-DD vs DD-MM-YYYY)');
          totalInconsistencies += 1;
        }
      }

      if (inferredType === 'string') {
        // Detect casing variants (e.g. "chennai" vs "Chennai")
        const lowerMap = new Map<string, Set<string>>();
        nonNulls.forEach(val => {
          const str = String(val).trim();
          const low = str.toLowerCase();
          if (!lowerMap.has(low)) lowerMap.set(low, new Set());
          lowerMap.get(low)!.add(str);
        });
        const variants: string[] = [];
        lowerMap.forEach((set, low) => {
          if (set.size > 1) {
            variants.push(Array.from(set).join(', '));
          }
        });
        if (variants.length > 0) {
          colProf.inconsistenciesCount = (colProf.inconsistenciesCount || 0) + variants.length;
          colProf.inconsistenciesExamples?.push(`Mixed casing: ${variants.slice(0, 2).join(' | ')}`);
          totalInconsistencies += variants.length;
        }

        // Detect whitespace
        const trailingSpaceCount = nonNulls.filter(v => typeof v === 'string' && (v.startsWith(' ') || v.endsWith(' '))).length;
        if (trailingSpaceCount > 0) {
          colProf.inconsistenciesCount = (colProf.inconsistenciesCount || 0) + trailingSpaceCount;
          colProf.inconsistenciesExamples?.push(`${trailingSpaceCount} entries with leading/trailing whitespace`);
          totalInconsistencies += trailingSpaceCount;
        }
      }

      // Numerical statistics & Outlier Detection
      if (inferredType === 'number') {
        const numValues = nonNulls
          .map(v => typeof v === 'number' ? v : Number(String(v).replace(/[$€£,]/g, '')))
          .filter(v => !isNaN(v))
          .sort((a, b) => a - b);

        if (numValues.length > 0) {
          const sum = numValues.reduce((acc, v) => acc + v, 0);
          const mean = sum / numValues.length;
          const min = numValues[0];
          const max = numValues[numValues.length - 1];

          // Median
          const mid = Math.floor(numValues.length / 2);
          const median = numValues.length % 2 !== 0 ? numValues[mid] : (numValues[mid - 1] + numValues[mid]) / 2;

          // Standard Deviation
          const variance = numValues.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / numValues.length;
          const stdDev = Math.sqrt(variance);

          // Quartiles
          const q1Idx = Math.floor(numValues.length * 0.25);
          const q3Idx = Math.floor(numValues.length * 0.75);
          const q1 = numValues[q1Idx];
          const q3 = numValues[q3Idx];
          const iqr = q3 - q1;

          // IQR Outliers (values < Q1 - 1.5*IQR or > Q3 + 1.5*IQR)
          const lowerBound = q1 - 1.5 * iqr;
          const upperBound = q3 + 1.5 * iqr;
          const outliers = numValues.filter(v => v < lowerBound || v > upperBound);

          colProf.min = min;
          colProf.max = max;
          colProf.mean = Number(mean.toFixed(2));
          colProf.median = Number(median.toFixed(2));
          colProf.stdDev = Number(stdDev.toFixed(2));
          colProf.q1 = q1;
          colProf.q3 = q3;
          colProf.outlierCount = outliers.length;
          colProf.outliers = outliers.slice(0, 5);

          if (outliers.length > 0) {
            colProf.inconsistenciesCount = (colProf.inconsistenciesCount || 0) + outliers.length;
            colProf.inconsistenciesExamples?.push(`${outliers.length} extreme statistical outlier(s) detected via IQR`);
            totalInconsistencies += outliers.length;
          }
        }
      } else {
        // Frequency distribution for categories
        const freqMap = new Map<string, number>();
        nonNulls.forEach(v => {
          const key = String(v).trim();
          freqMap.set(key, (freqMap.get(key) || 0) + 1);
        });
        const sortedCats = Array.from(freqMap.entries())
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(([value, count]) => ({
            value,
            count,
            percentage: Number(((count / totalRows) * 100).toFixed(1))
          }));
        colProf.topCategories = sortedCats;
      }

      return colProf;
    });

    const missingPercentage = totalCells > 0 ? (totalMissingCells / totalCells) * 100 : 0;
    const inconsistencyPercentage = totalRows > 0 ? Math.min(100, (totalInconsistencies / (totalRows * columns.length)) * 100 * 5) : 0;

    // Weighted Quality Score Formula:
    // Quality Score = 100 - (Wm*M + Wd*D + Wi*I)
    const Wm = 0.40;
    const Wd = 0.35;
    const Wi = 0.25;

    const penalty = (Wm * missingPercentage) + (Wd * duplicatePercentage) + (Wi * inconsistencyPercentage);
    const overallScore = Math.max(0, Math.min(100, Math.round(100 - penalty)));

    const dimensions: QualityDimensions = {
      completeness: Math.max(0, Math.min(100, Math.round(100 - missingPercentage * 2))),
      uniqueness: Math.max(0, Math.min(100, Math.round(100 - duplicatePercentage * 2.5))),
      consistency: Math.max(0, Math.min(100, Math.round(100 - inconsistencyPercentage * 2))),
      validity: Math.max(0, Math.min(100, Math.round(100 - (missingPercentage + inconsistencyPercentage))))
    };

    const quality: QualityScore = {
      overall: overallScore,
      dimensions,
      formula: 'Quality Score = 100 - (0.40 * Missing% + 0.35 * Duplicate% + 0.25 * Inconsistency%)',
      missingPercentage: Number(missingPercentage.toFixed(1)),
      duplicatePercentage: Number(duplicatePercentage.toFixed(1)),
      inconsistencyPercentage: Number(inconsistencyPercentage.toFixed(1))
    };

    return { profile, quality };
  }

  // ==========================================
  // DATA CLEANING OPERATIONS
  // ==========================================

  /**
   * Impute or handle missing values.
   */
  static imputeMissing(
    rows: DataRow[],
    column: string,
    method: 'mean' | 'median' | 'mode' | 'custom' | 'ffill' | 'bfill' | 'drop_rows' | 'drop_col',
    customValue?: any
  ): { rows: DataRow[]; affected: number } {
    if (method === 'drop_col') {
      const updated = rows.map(r => {
        const copy = { ...r };
        delete copy[column];
        return copy;
      });
      return { rows: updated, affected: rows.length };
    }

    if (method === 'drop_rows') {
      const initialCount = rows.length;
      const updated = rows.filter(r => r[column] !== null && r[column] !== undefined && r[column] !== '' && r[column] !== 'NULL');
      return { rows: updated, affected: initialCount - updated.length };
    }

    // Compute replacement value
    let replacement: any = null;
    const nonNulls = rows.map(r => r[column]).filter(v => v !== null && v !== undefined && v !== '' && v !== 'NULL');

    if (method === 'mean' || method === 'median') {
      const nums = nonNulls.map(v => Number(v)).filter(v => !isNaN(v)).sort((a, b) => a - b);
      if (nums.length > 0) {
        if (method === 'mean') {
          replacement = Number((nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2));
        } else {
          const mid = Math.floor(nums.length / 2);
          replacement = nums.length % 2 !== 0 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
        }
      }
    } else if (method === 'mode') {
      const counts = new Map<any, number>();
      nonNulls.forEach(v => counts.set(v, (counts.get(v) || 0) + 1));
      let maxCnt = 0;
      counts.forEach((cnt, val) => {
        if (cnt > maxCnt) {
          maxCnt = cnt;
          replacement = val;
        }
      });
    } else if (method === 'custom') {
      replacement = customValue !== undefined ? customValue : 'Unknown';
    }

    let affected = 0;
    let lastSeen: any = null;

    let updated = rows.map(r => {
      const val = r[column];
      const isMissing = val === null || val === undefined || val === '' || val === 'NULL';
      if (isMissing) {
        affected++;
        if (method === 'ffill') {
          return { ...r, [column]: lastSeen };
        }
        return { ...r, [column]: replacement };
      } else {
        lastSeen = val;
        return { ...r };
      }
    });

    if (method === 'bfill') {
      let nextSeen: any = null;
      for (let i = updated.length - 1; i >= 0; i--) {
        const val = updated[i][column];
        if (val === null || val === undefined || val === '' || val === 'NULL') {
          updated[i] = { ...updated[i], [column]: nextSeen };
        } else {
          nextSeen = val;
        }
      }
    }

    return { rows: updated, affected };
  }

  /**
   * Remove duplicate rows (all columns, or based on key columns).
   */
  static removeDuplicates(
    rows: DataRow[],
    subsetColumns?: string[],
    keep: 'first' | 'last' | 'none' = 'first'
  ): { rows: DataRow[]; affected: number } {
    const counts = new Map<string, number>();
    const getKey = (row: DataRow) => {
      if (!subsetColumns || subsetColumns.length === 0) return JSON.stringify(row);
      const sub: Record<string, any> = {};
      subsetColumns.forEach(c => { sub[c] = row[c]; });
      return JSON.stringify(sub);
    };

    rows.forEach(r => {
      const k = getKey(r);
      counts.set(k, (counts.get(k) || 0) + 1);
    });

    const seen = new Set<string>();
    const filtered: DataRow[] = [];

    if (keep === 'first') {
      rows.forEach(r => {
        const k = getKey(r);
        if (!seen.has(k)) {
          seen.add(k);
          filtered.push({ ...r });
        }
      });
    } else if (keep === 'last') {
      for (let i = rows.length - 1; i >= 0; i--) {
        const r = rows[i];
        const k = getKey(r);
        if (!seen.has(k)) {
          seen.add(k);
          filtered.unshift({ ...r });
        }
      }
    } else {
      // Keep none (remove all duplicate rows completely)
      rows.forEach(r => {
        const k = getKey(r);
        if (counts.get(k) === 1) {
          filtered.push({ ...r });
        }
      });
    }

    return { rows: filtered, affected: rows.length - filtered.length };
  }

  /**
   * Standardize Date formats to uniform YYYY-MM-DD.
   */
  static standardizeDates(rows: DataRow[], column: string): { rows: DataRow[]; affected: number } {
    let affected = 0;
    const updated = rows.map(r => {
      const val = r[column];
      if (!val) return { ...r };

      const str = String(val).trim();
      let formatted: string | null = null;

      // Handle DD-MM-YYYY or DD/MM/YYYY
      const ddmmyyyy = str.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
      if (ddmmyyyy) {
        const day = ddmmyyyy[1].padStart(2, '0');
        const month = ddmmyyyy[2].padStart(2, '0');
        const year = ddmmyyyy[3];
        formatted = `${year}-${month}-${day}`;
      }

      // Handle YYYY/MM/DD
      const yyyymmdd = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
      if (yyyymmdd) {
        const year = yyyymmdd[1];
        const month = yyyymmdd[2].padStart(2, '0');
        const day = yyyymmdd[3].padStart(2, '0');
        formatted = `${year}-${month}-${day}`;
      }

      // Fallback Date parser
      if (!formatted) {
        const ts = Date.parse(str);
        if (!isNaN(ts)) {
          const d = new Date(ts);
          formatted = d.toISOString().split('T')[0];
        }
      }

      if (formatted && formatted !== str) {
        affected++;
        return { ...r, [column]: formatted };
      }
      return { ...r };
    });

    return { rows: updated, affected };
  }

  /**
   * Trim leading/trailing and duplicate whitespace across string columns.
   */
  static trimWhitespace(rows: DataRow[], columns?: string[]): { rows: DataRow[]; affected: number } {
    let affected = 0;
    const updated = rows.map(r => {
      const copy = { ...r };
      const targetCols = columns && columns.length > 0 ? columns : Object.keys(r);
      targetCols.forEach(col => {
        if (typeof copy[col] === 'string') {
          const original = copy[col];
          const trimmed = original.trim().replace(/\s+/g, ' ');
          if (original !== trimmed) {
            affected++;
            copy[col] = trimmed;
          }
        }
      });
      return copy;
    });

    return { rows: updated, affected };
  }

  /**
   * Standardize string casing: 'title', 'upper', 'lower'.
   */
  static standardizeCasing(
    rows: DataRow[],
    column: string,
    casing: 'title' | 'upper' | 'lower'
  ): { rows: DataRow[]; affected: number } {
    let affected = 0;
    const toTitle = (str: string) =>
      str.toLowerCase().replace(/(?:^|\s|-|\/)\S/g, char => char.toUpperCase());

    const updated = rows.map(r => {
      const val = r[column];
      if (typeof val !== 'string') return { ...r };

      let nextVal = val;
      if (casing === 'title') nextVal = toTitle(val.trim());
      else if (casing === 'upper') nextVal = val.trim().toUpperCase();
      else if (casing === 'lower') nextVal = val.trim().toLowerCase();

      if (nextVal !== val) {
        affected++;
        return { ...r, [column]: nextVal };
      }
      return { ...r };
    });

    return { rows: updated, affected };
  }

  /**
   * Category normalization (canonicalizes fuzzy spelling, e.g. "chennai" -> "Chennai", "ENG" -> "Engineering").
   */
  static normalizeCategories(rows: DataRow[], column: string): { rows: DataRow[]; affected: number } {
    // Detect dictionary of canonical values based on most frequent properly capitalized form
    const canonicalMap = new Map<string, string>();
    const freqMap = new Map<string, number>();

    rows.forEach(r => {
      const val = r[column];
      if (typeof val === 'string' && val.trim()) {
        const raw = val.trim();
        freqMap.set(raw, (freqMap.get(raw) || 0) + 1);
      }
    });

    // Special enterprise synonym shortcuts
    const synonyms: Record<string, string> = {
      'eng': 'Engineering',
      'it': 'IT Support',
      'fin': 'Finance',
      'mktg': 'Marketing',
      'chennai': 'Chennai',
      'bangalore': 'Bangalore',
      'mumbai': 'Mumbai',
      'delhi': 'Delhi',
      'new york': 'New York',
      'san francisco': 'San Francisco',
      'london': 'London',
      'paris': 'Paris'
    };

    let affected = 0;
    const updated = rows.map(r => {
      const val = r[column];
      if (typeof val !== 'string') return { ...r };
      const raw = val.trim();
      const lower = raw.toLowerCase();

      let target = synonyms[lower];
      if (!target) {
        // Use Title Case canonical
        target = raw.toLowerCase().replace(/(?:^|\s)\S/g, c => c.toUpperCase());
      }

      if (target !== val) {
        affected++;
        return { ...r, [column]: target };
      }
      return { ...r };
    });

    return { rows: updated, affected };
  }

  /**
   * Clean currency columns (strips $, €, £, and commas).
   */
  static cleanCurrency(rows: DataRow[], column: string): { rows: DataRow[]; affected: number } {
    let affected = 0;
    const updated = rows.map(r => {
      const val = r[column];
      if (val === null || val === undefined) return { ...r };
      const str = String(val).trim();
      const cleaned = str.replace(/[$€£,]/g, '').trim();
      const num = Number(cleaned);
      if (!isNaN(num) && cleaned !== str) {
        affected++;
        return { ...r, [column]: num };
      }
      return { ...r };
    });

    return { rows: updated, affected };
  }

  /**
   * Handle statistical outliers using IQR or Z-score method.
   */
  static handleOutliers(
    rows: DataRow[],
    column: string,
    method: 'iqr' | 'zscore',
    action: 'cap' | 'remove'
  ): { rows: DataRow[]; affected: number } {
    const nums = rows
      .map(r => Number(r[column]))
      .filter(v => !isNaN(v) && v !== null)
      .sort((a, b) => a - b);

    if (nums.length < 4) return { rows, affected: 0 };

    let lowerBound = 0;
    let upperBound = 0;

    if (method === 'iqr') {
      const q1 = nums[Math.floor(nums.length * 0.25)];
      const q3 = nums[Math.floor(nums.length * 0.75)];
      const iqr = q3 - q1;
      lowerBound = q1 - 1.5 * iqr;
      upperBound = q3 + 1.5 * iqr;
    } else {
      // Z-score method (threshold = 2.5)
      const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
      const variance = nums.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / nums.length;
      const stdDev = Math.sqrt(variance) || 1;
      lowerBound = mean - 2.5 * stdDev;
      upperBound = mean + 2.5 * stdDev;
    }

    let affected = 0;

    if (action === 'remove') {
      const filtered = rows.filter(r => {
        const val = Number(r[column]);
        if (isNaN(val)) return true;
        const isOutlier = val < lowerBound || val > upperBound;
        if (isOutlier) affected++;
        return !isOutlier;
      });
      return { rows: filtered, affected };
    } else {
      // Winsorization (capping to bounds)
      const updated = rows.map(r => {
        const val = Number(r[column]);
        if (isNaN(val)) return { ...r };
        if (val < lowerBound) {
          affected++;
          return { ...r, [column]: Math.round(lowerBound) };
        }
        if (val > upperBound) {
          affected++;
          return { ...r, [column]: Math.round(upperBound) };
        }
        return { ...r };
      });
      return { rows: updated, affected };
    }
  }

  /**
   * Apply a Custom Cleaning Rule (e.g. IF Revenue IS NULL THEN Median, or IF Age < 0 THEN drop/cap).
   */
  static applyCustomRule(rows: DataRow[], rule: CustomRule): { rows: DataRow[]; affected: number } {
    let affected = 0;

    // Check if replacing with median
    let medianVal: number = 0;
    if (rule.action === 'replace_median') {
      const nums = rows.map(r => Number(r[rule.column])).filter(v => !isNaN(v) && v !== null).sort((a, b) => a - b);
      if (nums.length > 0) {
        medianVal = nums[Math.floor(nums.length / 2)];
      }
    }

    const testCondition = (val: any): boolean => {
      if (rule.operator === 'is_null') {
        return val === null || val === undefined || val === '' || val === 'NULL';
      }
      if (rule.operator === 'equals') return String(val).toLowerCase() === rule.value.toLowerCase();
      if (rule.operator === 'not_equals') return String(val).toLowerCase() !== rule.value.toLowerCase();
      if (rule.operator === 'contains') return String(val).toLowerCase().includes(rule.value.toLowerCase());
      if (rule.operator === 'greater_than') return Number(val) > Number(rule.value);
      if (rule.operator === 'less_than') return Number(val) < Number(rule.value);
      return false;
    };

    if (rule.action === 'drop_row') {
      const initialCount = rows.length;
      const filtered = rows.filter(r => !testCondition(r[rule.column]));
      return { rows: filtered, affected: initialCount - filtered.length };
    }

    const updated = rows.map(r => {
      if (testCondition(r[rule.column])) {
        affected++;
        let replacement: any = rule.targetValue;
        if (rule.action === 'replace_median') replacement = medianVal;
        if (rule.action === 'mark_invalid') replacement = '[INVALID]';
        return { ...r, [rule.column]: replacement };
      }
      return { ...r };
    });

    return { rows: updated, affected };
  }

  // ==========================================
  // TRANSFORMATION STUDIO OPERATIONS (Power Query)
  // ==========================================

  static renameColumn(rows: DataRow[], oldName: string, newName: string): DataRow[] {
    if (!newName.trim() || oldName === newName) return rows;
    return rows.map(r => {
      const copy: DataRow = {};
      Object.keys(r).forEach(k => {
        if (k === oldName) copy[newName.trim()] = r[k];
        else copy[k] = r[k];
      });
      return copy;
    });
  }

  static dropColumn(rows: DataRow[], column: string): DataRow[] {
    return rows.map(r => {
      const copy = { ...r };
      delete copy[column];
      return copy;
    });
  }

  static filterRows(rows: DataRow[], column: string, operator: string, value: string): DataRow[] {
    return rows.filter(r => {
      const val = r[column];
      if (operator === 'equals') return String(val).toLowerCase() === value.toLowerCase();
      if (operator === 'not_equals') return String(val).toLowerCase() !== value.toLowerCase();
      if (operator === 'contains') return String(val).toLowerCase().includes(value.toLowerCase());
      if (operator === 'greater_than') return Number(val) > Number(value);
      if (operator === 'less_than') return Number(val) < Number(value);
      if (operator === 'is_null') return val === null || val === undefined || val === '' || val === 'NULL';
      if (operator === 'is_not_null') return val !== null && val !== undefined && val !== '' && val !== 'NULL';
      return true;
    });
  }

  static sortRows(rows: DataRow[], column: string, direction: 'asc' | 'desc'): DataRow[] {
    return [...rows].sort((a, b) => {
      const valA = a[column];
      const valB = b[column];
      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;
      if (typeof valA === 'number' && typeof valB === 'number') {
        return direction === 'asc' ? valA - valB : valB - valA;
      }
      const cmp = String(valA).localeCompare(String(valB));
      return direction === 'asc' ? cmp : -cmp;
    });
  }

  static splitColumn(rows: DataRow[], column: string, delimiter: string, col1: string, col2: string): DataRow[] {
    return rows.map(r => {
      const val = String(r[column] ?? '');
      const parts = val.split(delimiter);
      return {
        ...r,
        [col1.trim()]: parts[0]?.trim() ?? '',
        [col2.trim()]: parts.slice(1).join(delimiter).trim()
      };
    });
  }

  static mergeColumns(rows: DataRow[], col1: string, col2: string, separator: string, newCol: string): DataRow[] {
    return rows.map(r => {
      const val1 = r[col1] ?? '';
      const val2 = r[col2] ?? '';
      return {
        ...r,
        [newCol.trim()]: `${val1}${separator}${val2}`
      };
    });
  }

  static changeDataType(rows: DataRow[], column: string, targetType: DataType): DataRow[] {
    return rows.map(r => {
      const val = r[column];
      if (val === null || val === undefined) return { ...r };
      let converted = val;
      if (targetType === 'number') converted = Number(String(val).replace(/[$€£,]/g, '')) || 0;
      else if (targetType === 'string') converted = String(val);
      else if (targetType === 'boolean') converted = Boolean(val);
      else if (targetType === 'date') {
        const ts = Date.parse(String(val));
        if (!isNaN(ts)) converted = new Date(ts).toISOString().split('T')[0];
      }
      return { ...r, [column]: converted };
    });
  }

  static addCalculatedColumn(rows: DataRow[], newColName: string, formulaStr: string): DataRow[] {
    return rows.map(r => {
      try {
        // Replace bracket tokens like [Revenue] or [Salary] with row values
        let expr = formulaStr.replace(/\[([^\]]+)\]/g, (_, col) => {
          const v = r[col.trim()];
          if (v === null || v === undefined) return '0';
          if (typeof v === 'number') return String(v);
          return `"${String(v).replace(/"/g, '\\"')}"`;
        });
        // Safe arithmetic eval
        // eslint-disable-next-line no-new-func
        const result = Function(`"use strict"; return (${expr});`)();
        return {
          ...r,
          [newColName.trim()]: typeof result === 'number' ? Number(result.toFixed(2)) : result
        };
      } catch {
        return { ...r, [newColName.trim()]: null };
      }
    });
  }

  /**
   * 1-Click Auto-Clean Suite:
   * Detects all issues in one pass and applies the recommended cleaning sequence:
   * 1. Remove duplicate records.
   * 2. Trim whitespace across all string columns.
   * 3. Impute missing numerical columns with Median, and categorical with Mode.
   * 4. Standardize all detected date columns.
   * 5. Standardize categories & casings.
   * 6. Clean currency numbers.
   */
  static runAutoCleanSuite(
    rows: DataRow[],
    columns: string[]
  ): { cleanedRows: DataRow[]; steps: TransformationStep[] } {
    let currentRows = [...rows];
    const steps: TransformationStep[] = [];

    // Step 1: Remove duplicates
    const dupRes = this.removeDuplicates(currentRows);
    if (dupRes.affected > 0) {
      currentRows = dupRes.rows;
      steps.push({
        id: `step-${Date.now()}-1`,
        action: 'remove_duplicates',
        description: `Removed ${dupRes.affected} duplicate record(s)`,
        timestamp: new Date().toLocaleTimeString(),
        affectedRowsCount: dupRes.affected
      });
    }

    // Step 2: Trim whitespace
    const trimRes = this.trimWhitespace(currentRows, columns);
    if (trimRes.affected > 0) {
      currentRows = trimRes.rows;
      steps.push({
        id: `step-${Date.now()}-2`,
        action: 'trim_whitespace',
        description: `Trimmed leading/trailing whitespace across ${columns.length} columns (${trimRes.affected} cells)`,
        timestamp: new Date().toLocaleTimeString(),
        affectedRowsCount: trimRes.affected
      });
    }

    // Step 3: Handle missing values & format normalization per column
    columns.forEach(col => {
      const values = currentRows.map(r => r[col]);
      const type = this.detectColumnType(values);
      const missingCount = values.filter(v => v === null || v === undefined || v === '' || v === 'NULL').length;

      // Impute missing
      if (missingCount > 0) {
        if (type === 'number') {
          const impRes = this.imputeMissing(currentRows, col, 'median');
          currentRows = impRes.rows;
          steps.push({
            id: `step-${Date.now()}-${col}-imp`,
            action: 'impute_median',
            column: col,
            description: `Imputed ${impRes.affected} missing value(s) in "${col}" using Median`,
            timestamp: new Date().toLocaleTimeString(),
            affectedRowsCount: impRes.affected
          });
        } else {
          const impRes = this.imputeMissing(currentRows, col, 'mode');
          currentRows = impRes.rows;
          steps.push({
            id: `step-${Date.now()}-${col}-imp`,
            action: 'impute_mode',
            column: col,
            description: `Imputed ${impRes.affected} missing value(s) in "${col}" using Mode`,
            timestamp: new Date().toLocaleTimeString(),
            affectedRowsCount: impRes.affected
          });
        }
      }

      // Standardize Date
      if (type === 'date') {
        const dateRes = this.standardizeDates(currentRows, col);
        if (dateRes.affected > 0) {
          currentRows = dateRes.rows;
          steps.push({
            id: `step-${Date.now()}-${col}-date`,
            action: 'standardize_dates',
            column: col,
            description: `Standardized ${dateRes.affected} date value(s) in "${col}" to YYYY-MM-DD`,
            timestamp: new Date().toLocaleTimeString(),
            affectedRowsCount: dateRes.affected
          });
        }
      }

      // Standardize Categories
      if (type === 'string' && (col.toLowerCase().includes('city') || col.toLowerCase().includes('dept') || col.toLowerCase().includes('category') || col.toLowerCase().includes('status'))) {
        const catRes = this.normalizeCategories(currentRows, col);
        if (catRes.affected > 0) {
          currentRows = catRes.rows;
          steps.push({
            id: `step-${Date.now()}-${col}-cat`,
            action: 'normalize_categories',
            column: col,
            description: `Standardized and canonicalized categories in "${col}" (${catRes.affected} updated)`,
            timestamp: new Date().toLocaleTimeString(),
            affectedRowsCount: catRes.affected
          });
        }
      }
    });

    return { cleanedRows: currentRows, steps };
  }
}
