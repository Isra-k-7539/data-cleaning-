import { SAMPLE_DATASETS } from './data/sampleDatasets';
import { DataEngine } from './services/dataEngine';
import {
  AutomationJob,
  CleaningActionType,
  DataRow,
  Dataset,
  PipelineTemplate,
  TransformationStep,
  ViewType
} from './types';

export class AppState {
  private static instance: AppState;

  datasets: Dataset[] = [];
  activeDatasetId: string = '';
  currentView: ViewType = 'overview';
  isAIOpen: boolean = false;
  searchFilter: string = '';
  listeners: (() => void)[] = [];

  automationJobs: AutomationJob[] = [
    {
      id: 'job-1',
      name: 'Daily Sales Ledger Reconciler',
      datasetName: 'Global Sales & Revenue Logs',
      templateName: 'Sales Data Reconciler & Cleaner',
      frequency: 'Daily',
      nextRun: '2026-11-11 02:00 AM',
      status: 'Active',
      lastRunStatus: 'Success',
      lastRunTimestamp: '2026-11-10 02:00 AM',
      recordsCleaned: 20
    },
    {
      id: 'job-2',
      name: 'Weekly Customer CRM Deduplication',
      datasetName: 'Customer Demographics & CRM',
      templateName: 'Customer CRM Standardization',
      frequency: 'Weekly',
      nextRun: '2026-11-16 04:00 AM',
      status: 'Active',
      lastRunStatus: 'Success',
      lastRunTimestamp: '2026-11-09 04:00 AM',
      recordsCleaned: 15
    },
    {
      id: 'job-3',
      name: 'Monthly Employee Payroll Sanity Audit',
      datasetName: 'Employee HR & Payroll Audit',
      templateName: 'Employee Payroll & HR Audit',
      frequency: 'Monthly',
      nextRun: '2026-12-01 01:00 AM',
      status: 'Paused',
      lastRunStatus: 'Success',
      lastRunTimestamp: '2026-11-01 01:00 AM',
      recordsCleaned: 13
    }
  ];

  pipelineTemplates: PipelineTemplate[] = [
    {
      id: 'template-sales',
      name: 'Sales Data Reconciler & Cleaner',
      category: 'Sales',
      description: 'Deduplicates orders, fixes mixed date separators, normalizes city spellings (chennai -> Chennai), and imputes missing revenue using the median.',
      icon: 'receipt_long',
      steps: [
        { action: 'remove_duplicates', description: 'Deduplicate redundant transaction orders' },
        { action: 'trim_whitespace', description: 'Trim extraneous whitespace from customer and city names' },
        { action: 'normalize_categories', column: 'City', description: 'Canonicalize city spellings' },
        { action: 'standardize_dates', column: 'Date', description: 'Standardize dates to YYYY-MM-DD' },
        { action: 'impute_median', column: 'Revenue', description: 'Fill missing revenue values with median' }
      ]
    },
    {
      id: 'template-customer',
      name: 'Customer CRM Standardization',
      category: 'Customer',
      description: 'Removes duplicate CRM profiles, trims customer names, caps invalid negative ages, and normalizes address cities.',
      icon: 'people',
      steps: [
        { action: 'remove_duplicates', description: 'Eliminate duplicate CRM contacts' },
        { action: 'trim_whitespace', description: 'Trim whitespace in Full Name & City' },
        { action: 'case_standardize', column: 'Full_Name', description: 'Capitalize full names to Title Case', params: { casing: 'title' } },
        { action: 'normalize_categories', column: 'City', description: 'Standardize international cities' },
        { action: 'custom_rule', column: 'Age', description: 'Fix negative ages (mark or impute median)', params: { operator: 'less_than', value: '0', action: 'replace_median' } }
      ]
    },
    {
      id: 'template-employee',
      name: 'Employee Payroll & HR Audit',
      category: 'HR',
      description: 'Reconciles department abbreviations (ENG -> Engineering), standardizes joining dates, and caps extreme salary typos via IQR.',
      icon: 'badge',
      steps: [
        { action: 'remove_duplicates', description: 'Drop duplicated employee rows' },
        { action: 'normalize_categories', column: 'Department', description: 'Canonicalize department labels' },
        { action: 'standardize_dates', column: 'Hire_Date', description: 'Unify hire dates to ISO format' },
        { action: 'handle_outliers_iqr', column: 'Salary', description: 'Winsorize salary typos via IQR method' },
        { action: 'impute_mode', column: 'Department', description: 'Fill missing departments with mode' }
      ]
    },
    {
      id: 'template-finance',
      name: 'Financial Ledger Sanity Audit',
      category: 'Finance',
      description: 'Removes duplicate invoice lines, cleans currency formatting, unifies cost centers, and verifies tax calculations.',
      icon: 'account_balance',
      steps: [
        { action: 'remove_duplicates', description: 'Eliminate duplicate invoices' },
        { action: 'normalize_categories', column: 'Cost_Center', description: 'Normalize cost center names' },
        { action: 'standardize_dates', column: 'Date', description: 'Unify accounting dates' },
        { action: 'impute_median', column: 'Amount', description: 'Fill missing expense amounts with median' }
      ]
    }
  ];

  private constructor() {
    this.initDefaultDatasets();
  }

  static getInstance(): AppState {
    if (!AppState.instance) {
      AppState.instance = new AppState();
    }
    return AppState.instance;
  }

  private initDefaultDatasets() {
    SAMPLE_DATASETS.forEach(sample => {
      const columns = sample.rows.length > 0 ? Object.keys(sample.rows[0]) : [];
      const { profile, quality } = DataEngine.profileDataset(sample.rows, columns);

      const dataset: Dataset = {
        id: sample.id,
        name: sample.name,
        source: 'sample',
        uploadedAt: new Date().toLocaleTimeString(),
        rawRows: sample.rows.map(r => ({ ...r })),
        cleanedRows: sample.rows.map(r => ({ ...r })),
        columns,
        rawProfile: profile,
        cleanedProfile: profile,
        rawQuality: quality,
        cleanedQuality: quality,
        transformationHistory: [],
        undoStack: [],
        redoStack: [],
        sizeBytes: JSON.stringify(sample.rows).length
      };

      this.datasets.push(dataset);
    });

    if (this.datasets.length > 0) {
      this.activeDatasetId = this.datasets[0].id;
    }
  }

  getActiveDataset(): Dataset | undefined {
    return this.datasets.find(d => d.id === this.activeDatasetId);
  }

  setActiveDataset(id: string) {
    if (this.datasets.some(d => d.id === id)) {
      this.activeDatasetId = id;
      this.notify();
    }
  }

  setView(view: ViewType) {
    this.currentView = view;
    this.notify();
  }

  setSearchFilter(query: string) {
    this.searchFilter = query;
    this.notify();
  }

  toggleAI(open?: boolean) {
    this.isAIOpen = open !== undefined ? open : !this.isAIOpen;
    this.notify();
  }

  addUploadedDataset(name: string, rows: DataRow[], columns: string[]) {
    const { profile, quality } = DataEngine.profileDataset(rows, columns);
    const newDataset: Dataset = {
      id: `dataset-${Date.now()}`,
      name: name || 'Uploaded Dataset',
      source: 'upload',
      uploadedAt: new Date().toLocaleTimeString(),
      rawRows: rows.map(r => ({ ...r })),
      cleanedRows: rows.map(r => ({ ...r })),
      columns,
      rawProfile: profile,
      cleanedProfile: profile,
      rawQuality: quality,
      cleanedQuality: quality,
      transformationHistory: [],
      undoStack: [],
      redoStack: [],
      sizeBytes: JSON.stringify(rows).length
    };

    this.datasets.unshift(newDataset);
    this.activeDatasetId = newDataset.id;
    this.currentView = 'workspace';
    this.notify();
  }

  /**
   * Applies an arbitrary cleaning transformation with full undo/redo stack & profiling update.
   */
  applyTransformation(
    action: CleaningActionType,
    description: string,
    transformFn: (currentRows: DataRow[]) => { rows: DataRow[]; affected: number },
    column?: string,
    params?: Record<string, any>
  ) {
    const dataset = this.getActiveDataset();
    if (!dataset) return;

    // Push current to undo stack
    dataset.undoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.redoStack = []; // clear redo

    const result = transformFn(dataset.cleanedRows);
    dataset.cleanedRows = result.rows;

    // Refresh columns if columns changed
    if (dataset.cleanedRows.length > 0) {
      dataset.columns = Object.keys(dataset.cleanedRows[0]);
    }

    // Recalculate profile and quality
    const { profile, quality } = DataEngine.profileDataset(dataset.cleanedRows, dataset.columns);
    dataset.cleanedProfile = profile;
    dataset.cleanedQuality = quality;

    const step: TransformationStep = {
      id: `step-${Date.now()}`,
      action,
      description,
      column,
      params,
      timestamp: new Date().toLocaleTimeString(),
      affectedRowsCount: result.affected
    };
    dataset.transformationHistory.push(step);

    this.notify();
  }

  undo() {
    const dataset = this.getActiveDataset();
    if (!dataset || dataset.undoStack.length === 0) return;

    const previous = dataset.undoStack.pop()!;
    dataset.redoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.cleanedRows = previous;

    if (dataset.transformationHistory.length > 0) {
      dataset.transformationHistory.pop();
    }

    if (dataset.cleanedRows.length > 0) {
      dataset.columns = Object.keys(dataset.cleanedRows[0]);
    }
    const { profile, quality } = DataEngine.profileDataset(dataset.cleanedRows, dataset.columns);
    dataset.cleanedProfile = profile;
    dataset.cleanedQuality = quality;

    this.notify();
  }

  redo() {
    const dataset = this.getActiveDataset();
    if (!dataset || dataset.redoStack.length === 0) return;

    const next = dataset.redoStack.pop()!;
    dataset.undoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.cleanedRows = next;

    if (dataset.cleanedRows.length > 0) {
      dataset.columns = Object.keys(dataset.cleanedRows[0]);
    }
    const { profile, quality } = DataEngine.profileDataset(dataset.cleanedRows, dataset.columns);
    dataset.cleanedProfile = profile;
    dataset.cleanedQuality = quality;

    this.notify();
  }

  resetToRaw() {
    const dataset = this.getActiveDataset();
    if (!dataset) return;

    dataset.undoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.redoStack = [];
    dataset.cleanedRows = dataset.rawRows.map(r => ({ ...r }));
    dataset.columns = dataset.rawRows.length > 0 ? Object.keys(dataset.rawRows[0]) : [];
    dataset.cleanedProfile = dataset.rawProfile;
    dataset.cleanedQuality = dataset.rawQuality;
    dataset.transformationHistory = [];

    this.notify();
  }

  run1ClickAutoClean() {
    const dataset = this.getActiveDataset();
    if (!dataset) return;

    dataset.undoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.redoStack = [];

    const { cleanedRows, steps } = DataEngine.runAutoCleanSuite(dataset.cleanedRows, dataset.columns);
    dataset.cleanedRows = cleanedRows;
    if (cleanedRows.length > 0) {
      dataset.columns = Object.keys(cleanedRows[0]);
    }
    const { profile, quality } = DataEngine.profileDataset(cleanedRows, dataset.columns);
    dataset.cleanedProfile = profile;
    dataset.cleanedQuality = quality;
    dataset.transformationHistory.push(...steps);

    this.notify();
  }

  runTemplate(templateId: string) {
    const template = this.pipelineTemplates.find(t => t.id === templateId);
    const dataset = this.getActiveDataset();
    if (!template || !dataset) return;

    dataset.undoStack.push(dataset.cleanedRows.map(r => ({ ...r })));
    dataset.redoStack = [];

    let current = dataset.cleanedRows;
    const addedSteps: TransformationStep[] = [];

    template.steps.forEach(step => {
      let affected = 0;
      if (step.action === 'remove_duplicates') {
        const res = DataEngine.removeDuplicates(current);
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'trim_whitespace') {
        const res = DataEngine.trimWhitespace(current);
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'normalize_categories' && step.column) {
        const res = DataEngine.normalizeCategories(current, step.column);
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'standardize_dates' && step.column) {
        const res = DataEngine.standardizeDates(current, step.column);
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'impute_median' && step.column) {
        const res = DataEngine.imputeMissing(current, step.column, 'median');
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'impute_mode' && step.column) {
        const res = DataEngine.imputeMissing(current, step.column, 'mode');
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'case_standardize' && step.column) {
        const res = DataEngine.standardizeCasing(current, step.column, step.params?.casing || 'title');
        current = res.rows;
        affected = res.affected;
      } else if (step.action === 'handle_outliers_iqr' && step.column) {
        const res = DataEngine.handleOutliers(current, step.column, 'iqr', 'cap');
        current = res.rows;
        affected = res.affected;
      }

      addedSteps.push({
        id: `tpl-${Date.now()}-${step.action}`,
        action: step.action,
        column: step.column,
        description: `[Template: ${template.name}] ${step.description}`,
        timestamp: new Date().toLocaleTimeString(),
        affectedRowsCount: affected
      });
    });

    dataset.cleanedRows = current;
    if (current.length > 0) {
      dataset.columns = Object.keys(current[0]);
    }
    const { profile, quality } = DataEngine.profileDataset(current, dataset.columns);
    dataset.cleanedProfile = profile;
    dataset.cleanedQuality = quality;
    dataset.transformationHistory.push(...addedSteps);

    this.notify();
  }

  subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public notify() {
    this.listeners.forEach(l => l());
  }
}
